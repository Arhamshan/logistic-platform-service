import React, { useState } from 'react';
import { api } from '../services/api';
import { Search, Package, MapPin, Clock, CheckCircle2, AlertTriangle, Truck, XCircle } from 'lucide-react';

const STATUS_CONFIG = {
  PENDING:          { label: 'Pending',          color: '#d97706', bg: '#fffbeb', border: '#fde68a', icon: Clock           },
  RECEIVED:         { label: 'Received',          color: '#0369a1', bg: '#f0f9ff', border: '#bae6fd', icon: Package        },
  IN_TRANSIT:       { label: 'In Transit',        color: '#b45309', bg: '#fffbeb', border: '#fde68a', icon: Truck          },
  OUT_FOR_DELIVERY: { label: 'Out for Delivery',  color: '#6d28d9', bg: '#ede9fe', border: '#ddd6fe', icon: Truck          },
  DELIVERED:        { label: 'Delivered',          color: '#15803d', bg: '#f0fdf4', border: '#bbf7d0', icon: CheckCircle2  },
  EXCEPTION:        { label: 'Exception',          color: '#b91c1c', bg: '#fef2f2', border: '#fecaca', icon: AlertTriangle  },
};

export default function Tracking() {
  const [query, setQuery]         = useState('');
  const [result, setResult]       = useState(null);
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState(null);
  const [searched, setSearched]   = useState(false);

  const handleTrack = async (e) => {
    e?.preventDefault();
    const id = query.trim();
    if (!id) return;
    setLoading(true); setError(null); setResult(null); setSearched(false);
    try {
      const data = await api.getConsignmentTrack(id);
      setResult(data);
    } catch (err) {
      setError(err?.message || 'Tracking failed. Verify the consignment ID.');
    } finally {
      setLoading(false);
      setSearched(true);
    }
  };

  const StatusIcon = result ? (STATUS_CONFIG[result.status]?.icon || Package) : null;
  const statusCfg  = result ? (STATUS_CONFIG[result.status] || STATUS_CONFIG.PENDING) : null;

  return (
    <div className="page-container animate-slideup" style={{ maxWidth: 860, margin: '0 auto 48px auto' }}>

      <div className="page-header" style={{ flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
        <h2 className="page-title"><Search size={22} color="var(--primary)" /> Consignment Tracking</h2>
        <p className="page-subtitle">Enter a Consignment ID to view the full shipment journey.</p>
      </div>

      {/* Search Bar */}
      <form onSubmit={handleTrack} style={{ display: 'flex', gap: 10, marginBottom: 28 }}>
        <input
          className="form-input"
          style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', letterSpacing: '0.04em' }}
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Enter Consignment ID — e.g. CON-982103"
        />
        <button type="submit" className="btn btn-primary" style={{ flexShrink: 0, padding: '9px 24px' }} disabled={loading || !query.trim()}>
          {loading
            ? <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><Search size={15} className="spin" /> Tracking…</span>
            : <><Search size={15} /> Track</>
          }
        </button>
      </form>

      {/* Error */}
      {error && (
        <div style={{ padding: '16px 20px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 10, color: '#b91c1c', display: 'flex', gap: 10, alignItems: 'center', marginBottom: 24 }}>
          <XCircle size={18} />
          <span style={{ fontWeight: 500 }}>{error}</span>
        </div>
      )}

      {/* Result card */}
      {result && (
        <div className="animate-slideup">
          {/* Status Header */}
          <div className="section-card" style={{ marginBottom: 16, overflow: 'hidden' }}>
            <div style={{
              padding: '20px 24px',
              background: statusCfg.bg,
              borderBottom: `2px solid ${statusCfg.border}`,
              display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <div style={{ background: statusCfg.color, borderRadius: 10, padding: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <StatusIcon size={22} color="#fff" />
                </div>
                <div>
                  <p style={{ fontSize: '0.75rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: statusCfg.color, marginBottom: 2 }}>Current Status</p>
                  <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: statusCfg.color }}>{statusCfg.label}</h3>
                </div>
              </div>
              <span className="code-tag" style={{ fontSize: '0.95rem' }}>{result.consignmentId}</span>
            </div>

            <div style={{ padding: '20px 24px', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
              <div>
                <p style={{ fontSize: '0.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', marginBottom: 4 }}>Origin</p>
                <p style={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: 5 }}>
                  <MapPin size={14} color="var(--primary)" />
                  {result.sourceLocation || result.origin || '—'}
                </p>
              </div>
              <div>
                <p style={{ fontSize: '0.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', marginBottom: 4 }}>Destination</p>
                <p style={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: 5 }}>
                  <MapPin size={14} color="var(--success)" />
                  {result.destinationLocation || result.destination || '—'}
                </p>
              </div>
              <div>
                <p style={{ fontSize: '0.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', marginBottom: 4 }}>Items Count</p>
                <p style={{ fontWeight: 600 }}>{(result.items || []).length} package(s)</p>
              </div>
            </div>
          </div>

          {/* Timeline */}
          {(result.events || result.trackingEvents || []).length > 0 && (
            <div className="section-card">
              <div className="section-card-header">
                <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>Shipment Journey</span>
              </div>
              <div style={{ padding: '20px 24px' }}>
                {(result.events || result.trackingEvents || []).map((ev, i, arr) => {
                  const cfg = STATUS_CONFIG[ev.status] || STATUS_CONFIG.PENDING;
                  const EvIcon = cfg.icon;
                  const isLast = i === arr.length - 1;
                  return (
                    <div key={i} style={{ display: 'flex', gap: 14, position: 'relative' }}>
                      {/* Vertical line */}
                      {!isLast && (
                        <div style={{
                          position: 'absolute', left: 18, top: 38, bottom: -4,
                          width: 2, background: 'var(--border-color)'
                        }} />
                      )}

                      {/* Icon node */}
                      <div style={{
                        width: 36, height: 36, borderRadius: '50%', flexShrink: 0,
                        background: i === 0 ? cfg.color : '#f1f5f9',
                        border: `2px solid ${i === 0 ? cfg.color : 'var(--border-color)'}`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        zIndex: 1
                      }}>
                        <EvIcon size={16} color={i === 0 ? '#fff' : 'var(--text-muted)'} />
                      </div>

                      {/* Content */}
                      <div style={{ paddingBottom: isLast ? 0 : 20, flex: 1 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 4 }}>
                          <div>
                            <span style={{ fontWeight: 700, fontSize: '0.875rem', color: i === 0 ? cfg.color : 'var(--text-primary)' }}>
                              {cfg.label}
                            </span>
                            {ev.location && (
                              <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginLeft: 8 }}>
                                @ {ev.location}
                              </span>
                            )}
                          </div>
                          <span style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                            {ev.timestamp ? new Date(ev.timestamp).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : ev.time || ''}
                          </span>
                        </div>
                        {ev.description && (
                          <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: 2 }}>{ev.description}</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Items table */}
          {(result.items || []).length > 0 && (
            <div className="section-card" style={{ marginTop: 16 }}>
              <div className="section-card-header">
                <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>Package Items</span>
              </div>
              <div className="table-wrapper">
                <table className="data-table">
                  <thead>
                    <tr><th>#</th><th>Barcode</th><th>Weight (kg)</th><th>Dimensions</th></tr>
                  </thead>
                  <tbody>
                    {result.items.map((it, i) => (
                      <tr key={i}>
                        <td style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>{i + 1}</td>
                        <td><span className="code-tag">{it.barcode || it.barcodeId || '—'}</span></td>
                        <td>{it.weight || '—'}</td>
                        <td>{it.dimensions || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Empty state */}
      {searched && !result && !error && (
        <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--text-muted)' }}>
          <Package size={40} style={{ opacity: 0.25, marginBottom: 10 }} />
          <p>No tracking data found for <strong>{query}</strong></p>
        </div>
      )}

      {/* Prompt state */}
      {!searched && !loading && (
        <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--text-muted)' }}>
          <Search size={40} style={{ opacity: 0.2, marginBottom: 12 }} />
          <p style={{ fontSize: '0.9rem' }}>Enter a consignment ID above to trace the shipment journey.</p>
          <p style={{ fontSize: '0.8rem', marginTop: 6 }}>Try: <span className="code-tag">CON-982103</span></p>
        </div>
      )}
    </div>
  );
}
