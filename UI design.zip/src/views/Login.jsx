import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { Package, Lock, User, LogIn, AlertCircle } from 'lucide-react';

export default function Login() {
  const { login, registerDemoUser } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [requestId, setRequestId] = useState('REQ-001');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Connect to auth login API
      const res = await api.login(username, password, requestId);
      login(res.token, res.username, res.role);
    } catch (err) {
      setError(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoAccess = (role) => {
    const demoName = role === 'ADMIN' ? 'Admin_Demo' : 'Driver_Demo';
    registerDemoUser(demoName, role);
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      position: 'relative'
    }}>
      {/* Decorative ambient glowing backdrops */}
      <div style={{
        position: 'absolute',
        width: '300px',
        height: '300px',
        background: 'rgba(14, 165, 233, 0.15)',
        filter: 'blur(100px)',
        borderRadius: '50%',
        top: '20%',
        left: '20%',
        zIndex: 0
      }} />
      <div style={{
        position: 'absolute',
        width: '300px',
        height: '300px',
        background: 'rgba(139, 92, 246, 0.15)',
        filter: 'blur(100px)',
        borderRadius: '50%',
        bottom: '20%',
        right: '20%',
        zIndex: 0
      }} />

      <div className="glass-panel animate-slideup" style={{
        width: '100%',
        maxWidth: '440px',
        padding: '40px 32px',
        position: 'relative',
        zIndex: 1,
        borderRadius: '24px'
      }}>
        {/* Logo Branding */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: '32px' }}>
          <div style={{
            background: 'linear-gradient(135deg, #0ea5e9, #8b5cf6)',
            width: '56px',
            height: '56px',
            borderRadius: '16px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 8px 24px rgba(14, 165, 233, 0.4)',
            marginBottom: '16px'
          }}>
            <Package size={30} color="#000" strokeWidth={2.5} />
          </div>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800, color: 'var(--text-primary)', fontFamily: 'var(--font-display)' }}>
            ARQON Platform
          </h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Logistic Service Management Terminal
          </p>
        </div>

        {error && (
          <div style={{
            marginBottom: '20px',
            padding: '12px 16px',
            background: 'var(--danger-glow)',
            border: '1px solid rgba(239, 68, 68, 0.3)',
            borderRadius: '8px',
            display: 'flex',
            gap: '10px',
            alignItems: 'center'
          }}>
            <AlertCircle size={16} style={{ color: 'var(--danger)', flexShrink: 0 }} />
            <span style={{ fontSize: '0.8rem', color: 'var(--text-primary)' }}>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Username</label>
            <div style={{ position: 'relative' }}>
              <User size={16} style={{ position: 'absolute', left: '14px', top: '14px', color: 'var(--text-muted)' }} />
              <input
                type="text"
                className="form-input"
                style={{ paddingLeft: '40px' }}
                placeholder="Enter username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <div style={{ position: 'relative' }}>
              <Lock size={16} style={{ position: 'absolute', left: '14px', top: '14px', color: 'var(--text-muted)' }} />
              <input
                type="password"
                className="form-input"
                style={{ paddingLeft: '40px' }}
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">X-Request-ID (Optional)</label>
            <input
              type="text"
              className="form-input"
              value={requestId}
              onChange={(e) => setRequestId(e.target.value)}
              placeholder="REQ-001"
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary glow-cyan"
            style={{ width: '100%', padding: '12px', marginTop: '10px' }}
            disabled={loading}
          >
            <LogIn size={16} />
            {loading ? 'Authenticating...' : 'Sign In'}
          </button>
        </form>

        <div style={{
          position: 'relative',
          margin: '25px 0',
          textAlign: 'center'
        }}>
          <div style={{
            position: 'absolute',
            top: '50%',
            left: 0,
            right: 0,
            height: '1px',
            background: 'var(--border-color)',
            zIndex: 0
          }} />
          <span style={{
            position: 'relative',
            background: 'var(--bg-secondary)',
            padding: '0 10px',
            fontSize: '0.75rem',
            color: 'var(--text-muted)',
            zIndex: 1
          }}>
            QUICK DEMO BYPASS
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          <button
            type="button"
            className="btn btn-secondary"
            style={{ fontSize: '0.8rem', padding: '8px' }}
            onClick={() => handleDemoAccess('ADMIN')}
          >
            Demo Admin
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            style={{ fontSize: '0.8rem', padding: '8px' }}
            onClick={() => handleDemoAccess('DRIVER')}
          >
            Demo Driver
          </button>
        </div>
      </div>
    </div>
  );
}
