import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import {
  Package, Truck, CheckCircle2, ClipboardList,
  BarChart3, RefreshCw, ArrowRight, MapPin, Scan
} from 'lucide-react';

export default function Dashboard({ setActiveTab }) {
  const [summary, setSummary] = useState({ total: 0, pending: 0, inTransit: 0, delivered: 0 });
  const [statsLoading, setStatsLoading] = useState(false);
  const [recentConsignments, setRecentConsignments] = useState([]);
  const [locations, setLocations] = useState([]);

  const fetchData = async () => {
    setStatsLoading(true);
    try {
      const [res, store, locs] = await Promise.all([
        api.getConsignmentSummary(),
        Promise.resolve(api.getMockStore()),
        api.getLocations()
      ]);
      setSummary(res);
      setRecentConsignments([...store.consignments].reverse().slice(0, 5));
      setLocations(locs);
    } catch (err) {
      console.error(err);
    } finally {
      setStatsLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const stats = [
    { title: 'Total Consignments', value: summary.total,     icon: ClipboardList, color: 'var(--purple)',  bg: '#dbeafe', border: '#bfdbfe' },
    { title: 'Pending Shipments',  value: summary.pending,   icon: Package,       color: 'var(--warning)', bg: '#fffbeb', border: '#fde68a' },
    { title: 'In-Transit Freight', value: summary.inTransit, icon: Truck,         color: 'var(--primary)', bg: '#eef2ff', border: '#c7d2fe' },
    { title: 'Delivered Parcels',  value: summary.delivered, icon: CheckCircle2,  color: 'var(--success)', bg: '#f0fdf4', border: '#bbf7d0' },
  ];

  const STATUS_BADGE = {
    PENDING:    { cls: 'badge-warning', label: 'Pending'    },
    IN_TRANSIT: { cls: 'badge-info',    label: 'In Transit' },
    DELIVERED:  { cls: 'badge-success', label: 'Delivered'  },
    EXCEPTION:  { cls: 'badge-danger',  label: 'Exception'  },
  };

  const fmtDate = v => v ? new Date(v).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';

  return (
    <div className="page-container animate-slideup">

      {/* Header */}
      <div className="page-header">
        <div>
          <h2 className="page-title"><BarChart3 size={22} color="var(--primary)" /> Operational Dashboard</h2>
          <p className="page-subtitle">Real-time overview of ARQON logistics operations and shipment metrics.</p>
        </div>
        <button className="btn btn-secondary" onClick={fetchData} disabled={statsLoading}>
          <RefreshCw size={14} className={statsLoading ? 'spin' : ''} />
          Refresh
        </button>
      </div>

      {/* Stats Cards */}
      <div className="dashboard-grid" style={{ marginBottom: 24 }}>
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className="section-card" style={{ padding: '18px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <p style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', marginBottom: 5 }}>
                  {stat.title}
                </p>
                <p style={{ fontSize: '2rem', fontWeight: 800, fontFamily: 'var(--font-display)', color: stat.color, lineHeight: 1 }}>
                  {statsLoading ? '—' : stat.value}
                </p>
              </div>
              <div style={{ background: stat.bg, border: `1px solid ${stat.border}`, borderRadius: 12, padding: 12, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon size={22} color={stat.color} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Two-column layout */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>

        {/* Recent Consignments */}
        <div className="section-card">
          <div className="section-card-header">
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Package size={15} color="var(--text-secondary)" />
              <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>Recent Consignments</span>
            </div>
            <button className="btn btn-secondary" style={{ fontSize: '0.78rem', padding: '5px 12px' }}
              onClick={() => setActiveTab?.('consignments')}>
              View All <ArrowRight size={13} />
            </button>
          </div>
          <div className="table-wrapper">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Consignment ID</th>
                  <th>Route</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {recentConsignments.length === 0 ? (
                  <tr><td colSpan={4} style={{ textAlign: 'center', padding: 30, color: 'var(--text-muted)' }}>No data</td></tr>
                ) : recentConsignments.map(c => {
                  const sb = STATUS_BADGE[c.status] || { cls: 'badge-info', label: c.status };
                  return (
                    <tr key={c.consignmentId}>
                      <td><span className="code-tag">{c.consignmentId}</span></td>
                      <td style={{ fontSize: '0.8rem' }}>
                        <span style={{ color: 'var(--text-muted)' }}>{c.sourceLocation}</span>
                        <span style={{ margin: '0 4px', color: 'var(--text-muted)' }}>→</span>
                        <span>{c.destinationLocation}</span>
                      </td>
                      <td><span className={`badge ${sb.cls}`}>{sb.label}</span></td>
                      <td style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>{fmtDate(c.createdAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Hub Locations Overview */}
        <div className="section-card">
          <div className="section-card-header">
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <MapPin size={15} color="var(--text-secondary)" />
              <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>Registered Hubs</span>
            </div>
            <button className="btn btn-secondary" style={{ fontSize: '0.78rem', padding: '5px 12px' }}
              onClick={() => setActiveTab?.('locations')}>
              Manage <ArrowRight size={13} />
            </button>
          </div>
          <div style={{ padding: '8px 0' }}>
            {locations.length === 0 ? (
              <p style={{ textAlign: 'center', padding: 30, color: 'var(--text-muted)', fontSize: '0.85rem' }}>No locations loaded</p>
            ) : locations.map(loc => (
              <div key={loc.locationCode} style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '10px 20px', borderBottom: '1px solid #f1f5f9'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--success)', flexShrink: 0 }} />
                  <div>
                    <p style={{ fontWeight: 600, fontSize: '0.875rem' }}>{loc.name || loc.city}</p>
                    <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{loc.city}, {loc.country}</p>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span className="code-tag" style={{ fontSize: '0.72rem' }}>{loc.locationCode}</span>
                  <span className={`badge ${loc.type === 'HUB' ? 'badge-admin' : loc.type === 'GATEWAY' ? 'badge-warning' : loc.type === 'SORTING_CENTER' ? 'badge-info' : 'badge-success'}`}
                    style={{ fontSize: '0.65rem' }}>
                    {(loc.type || '').replace(/_/g, ' ')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Action Banner */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginTop: 16 }}>
        {[
          { label: 'Book New Consignment', icon: Package, tab: 'consignments', color: 'var(--primary)', bg: '#eef2ff', border: '#c7d2fe' },
          { label: 'Open Scanner Console', icon: Scan,    tab: 'scanner',      color: 'var(--success)', bg: '#f0fdf4', border: '#bbf7d0' },
          { label: 'Track a Shipment',     icon: Truck,   tab: 'tracking',     color: 'var(--warning)', bg: '#fffbeb', border: '#fde68a' },
        ].map(action => {
          const Icon = action.icon;
          return (
            <button key={action.tab}
              onClick={() => setActiveTab?.(action.tab)}
              style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '14px 18px',
                background: action.bg,
                border: `1.5px solid ${action.border}`,
                borderRadius: 10, cursor: 'pointer', textAlign: 'left',
                transition: 'var(--transition-fast)',
                fontFamily: 'var(--font-sans)'
              }}
              onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-1px)'; e.currentTarget.style.boxShadow = 'var(--shadow-sm)'; }}
              onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = 'none'; }}
            >
              <Icon size={20} color={action.color} />
              <span style={{ fontWeight: 600, fontSize: '0.875rem', color: 'var(--text-primary)' }}>{action.label}</span>
              <ArrowRight size={14} color="var(--text-muted)" style={{ marginLeft: 'auto' }} />
            </button>
          );
        })}
      </div>
    </div>
  );
}
