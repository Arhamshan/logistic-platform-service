import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { Scan, CheckCircle2, XCircle, RefreshCw, Volume2, VolumeX, MapPin } from 'lucide-react';

const STATUS_OPTIONS = ['RECEIVED', 'IN_TRANSIT', 'OUT_FOR_DELIVERY', 'DELIVERED', 'EXCEPTION'];

const STATUS_COLOR = {
  RECEIVED:         { bg: '#f0f9ff', color: '#0369a1', border: '#bae6fd' },
  IN_TRANSIT:       { bg: '#fffbeb', color: '#b45309', border: '#fde68a' },
  OUT_FOR_DELIVERY: { bg: '#ede9fe', color: '#6d28d9', border: '#ddd6fe' },
  DELIVERED:        { bg: '#f0fdf4', color: '#15803d', border: '#bbf7d0' },
  EXCEPTION:        { bg: '#fef2f2', color: '#b91c1c', border: '#fecaca' },
};

export default function Scanner() {
  const [locations, setLocations]       = useState([]);
  const [selectedHub, setSelectedHub]   = useState('');
  const [selectedStatus, setSelectedStatus] = useState('IN_TRANSIT');
  const [barcode, setBarcode]           = useState('');
  const [scanLog, setScanLog]           = useState([]);
  const [lastResult, setLastResult]     = useState(null); // 'ok' | 'fail'
  const [processing, setProcessing]     = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [stats, setStats]               = useState({ total: 0, success: 0, fail: 0 });
  const inputRef = useRef(null);

  useEffect(() => {
    api.getLocations().then(locs => {
      setLocations(locs);
      if (locs.length > 0) setSelectedHub(locs[0].locationCode);
    });
    inputRef.current?.focus();
  }, []);

  const playTone = (type) => {
    if (!audioEnabled) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      if (type === 'ok') {
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.setValueAtTime(1320, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.3);
        osc.start(); osc.stop(ctx.currentTime + 0.35);
      } else {
        osc.frequency.setValueAtTime(220, ctx.currentTime);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.4);
        osc.start(); osc.stop(ctx.currentTime + 0.45);
      }
    } catch (_) {}
  };

  const handleScan = async (e) => {
    e?.preventDefault();
    const code = barcode.trim();
    if (!code) return;
    setProcessing(true);
    setLastResult(null);

    try {
      const result = await api.scanItem(code, { location: selectedHub, status: selectedStatus });
      const entry = {
        id: Date.now(),
        barcode: code,
        status: selectedStatus,
        hub: selectedHub,
        time: new Date().toLocaleTimeString(),
        ok: true,
        msg: result?.message || 'Scan accepted',
      };
      setScanLog(prev => [entry, ...prev.slice(0, 49)]);
      setStats(s => ({ total: s.total + 1, success: s.success + 1, fail: s.fail }));
      setLastResult('ok');
      playTone('ok');
    } catch (err) {
      const entry = {
        id: Date.now(),
        barcode: code,
        status: selectedStatus,
        hub: selectedHub,
        time: new Date().toLocaleTimeString(),
        ok: false,
        msg: err?.message || 'Scan rejected',
      };
      setScanLog(prev => [entry, ...prev.slice(0, 49)]);
      setStats(s => ({ total: s.total + 1, success: s.success, fail: s.fail + 1 }));
      setLastResult('fail');
      playTone('fail');
    } finally {
      setProcessing(false);
      setBarcode('');
      inputRef.current?.focus();
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleScan();
  };

  const clearLog = () => {
    setScanLog([]);
    setStats({ total: 0, success: 0, fail: 0 });
    setLastResult(null);
  };

  return (
    <div className="page-container animate-slideup">
      <div className="page-header">
        <div>
          <h2 className="page-title"><Scan size={22} color="var(--primary)" /> Barcode Scanner</h2>
          <p className="page-subtitle">Scan shipment barcodes to update transit status in real-time.</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary" onClick={() => setAudioEnabled(p => !p)} title="Toggle sound">
            {audioEnabled ? <Volume2 size={15} /> : <VolumeX size={15} />}
            {audioEnabled ? 'Sound On' : 'Sound Off'}
          </button>
          <button className="btn btn-secondary" onClick={clearLog}>
            <RefreshCw size={14} /> Clear Log
          </button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        {/* Stats */}
        {[
          { label: 'Total Scans', value: stats.total, color: 'var(--primary)' },
          { label: 'Accepted',    value: stats.success, color: 'var(--success)' },
          { label: 'Rejected',    value: stats.fail,   color: 'var(--danger)' },
          { label: 'Success Rate', value: stats.total ? `${Math.round((stats.success / stats.total) * 100)}%` : '—', color: '#3b82f6' },
        ].map(s => (
          <div key={s.label} className="section-card" style={{ padding: '16px 20px' }}>
            <p style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', marginBottom: 4 }}>{s.label}</p>
            <p style={{ fontSize: '1.6rem', fontWeight: 800, color: s.color, fontFamily: 'var(--font-display)' }}>{s.value}</p>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 16 }}>

        {/* Scan Console */}
        <div className="section-card">
          <div className="section-card-header">
            <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>Scan Console</span>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Press Enter or click Scan</span>
          </div>
          <div className="section-card-body">
            {/* Hub + Status selectors */}
            <div className="grid-cols-2" style={{ marginBottom: 16 }}>
              <div className="form-group" style={{ marginBottom: 0 }}>
                <label className="form-label">Current Hub</label>
                <select className="form-select" value={selectedHub} onChange={e => setSelectedHub(e.target.value)}>
                  {locations.map(l => (
                    <option key={l.locationCode} value={l.locationCode}>{l.locationCode} — {l.city}</option>
                  ))}
                </select>
              </div>
              <div className="form-group" style={{ marginBottom: 0 }}>
                <label className="form-label">Scan Event Status</label>
                <select className="form-select" value={selectedStatus} onChange={e => setSelectedStatus(e.target.value)}>
                  {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
                </select>
              </div>
            </div>

            {/* Flash feedback */}
            <div style={{
              borderRadius: 10,
              padding: '14px 16px',
              marginBottom: 16,
              background: lastResult === 'ok' ? '#f0fdf4' : lastResult === 'fail' ? '#fef2f2' : '#f8fafc',
              border: `1.5px solid ${lastResult === 'ok' ? '#bbf7d0' : lastResult === 'fail' ? '#fecaca' : 'var(--border-color)'}`,
              display: 'flex', alignItems: 'center', gap: 10,
              transition: 'all 0.3s',
              minHeight: 56
            }}>
              {lastResult === 'ok'
                ? <CheckCircle2 size={22} color="var(--success)" />
                : lastResult === 'fail'
                ? <XCircle size={22} color="var(--danger)" />
                : <Scan size={22} color="var(--text-muted)" />
              }
              <span style={{
                fontWeight: 600, fontSize: '0.9rem',
                color: lastResult === 'ok' ? 'var(--success)' : lastResult === 'fail' ? 'var(--danger)' : 'var(--text-muted)'
              }}>
                {lastResult === 'ok' ? 'Scan Accepted ✓' : lastResult === 'fail' ? 'Scan Rejected ✗' : 'Awaiting barcode…'}
              </span>
            </div>

            {/* Barcode input */}
            <div style={{ display: 'flex', gap: 10 }}>
              <input
                ref={inputRef}
                className="form-input"
                style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.06em', fontSize: '1rem' }}
                value={barcode}
                onChange={e => setBarcode(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Scan or type barcode…"
                disabled={processing}
                autoFocus
              />
              <button
                className="btn btn-primary"
                style={{ padding: '9px 20px', flexShrink: 0 }}
                onClick={handleScan}
                disabled={processing || !barcode.trim()}
              >
                {processing ? <RefreshCw size={15} className="spin" /> : <Scan size={15} />}
                Scan
              </button>
            </div>

            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 8 }}>
              💡 Tip: Connect a physical barcode scanner — it types & submits automatically with Enter.
            </p>
          </div>
        </div>

        {/* Scan Log */}
        <div className="section-card" style={{ overflow: 'hidden' }}>
          <div className="section-card-header">
            <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>Scan Log</span>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Last 50 scans</span>
          </div>
          <div style={{ maxHeight: 380, overflowY: 'auto' }}>
            {scanLog.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--text-muted)' }}>
                <Scan size={32} style={{ opacity: 0.3, marginBottom: 8 }} />
                <p style={{ fontSize: '0.85rem' }}>No scans yet.</p>
              </div>
            ) : (
              <table className="data-table" style={{ fontSize: '0.8rem' }}>
                <thead>
                  <tr>
                    <th>Barcode</th>
                    <th>Status</th>
                    <th>Hub</th>
                    <th>Time</th>
                    <th style={{ textAlign: 'center' }}>Result</th>
                  </tr>
                </thead>
                <tbody>
                  {scanLog.map(entry => (
                    <tr key={entry.id} style={{ background: entry.ok ? undefined : '#fff5f5' }}>
                      <td style={{ fontFamily: 'var(--font-mono)' }}>{entry.barcode}</td>
                      <td>
                        <span style={{
                          padding: '2px 7px', borderRadius: 4, fontSize: '0.7rem', fontWeight: 700,
                          background: STATUS_COLOR[entry.status]?.bg || '#f1f5f9',
                          color: STATUS_COLOR[entry.status]?.color || 'var(--text-secondary)',
                          border: `1px solid ${STATUS_COLOR[entry.status]?.border || 'var(--border-color)'}`,
                        }}>
                          {entry.status}
                        </span>
                      </td>
                      <td>{entry.hub}</td>
                      <td style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{entry.time}</td>
                      <td style={{ textAlign: 'center' }}>
                        {entry.ok
                          ? <CheckCircle2 size={15} color="var(--success)" />
                          : <XCircle size={15} color="var(--danger)" />
                        }
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
