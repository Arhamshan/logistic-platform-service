import React, { useState, useEffect } from 'react';
import {
  Truck, Package, Clock, CheckCircle2, AlertCircle, MapPin, Phone, User,
  Upload, Camera, CheckSquare, FileText, Navigation, Star, Award, TrendingUp,
  Calendar, RefreshCw, ArrowRight, Download, ChevronRight, X
} from 'lucide-react';

export default function DriverDashboard({ setActiveTab }) {
  const [driverInfo, setDriverInfo] = useState({
    name: 'David Johnson',
    vehicleNo: 'LGX-2024-001',
    route: 'Route-A',
    shiftStart: '08:00 AM',
    shiftEnd: '05:00 PM'
  });

  const [driverStats, setDriverStats] = useState({
    todayDeliveries: 12,
    completedToday: 8,
    pendingPODs: 4,
    completionRate: 85
  });

  const [podList, setPodList] = useState([
    {
      id: 'POD-2024-001',
      consignmentId: 'CNS-10001',
      customerName: 'John Doe',
      address: '123 Market Street, Downtown',
      phone: '+1-555-0101',
      status: 'pending',
      eta: '10:30 AM',
      distance: '2.5 km'
    },
    {
      id: 'POD-2024-002',
      consignmentId: 'CNS-10002',
      customerName: 'Sarah Wilson',
      address: '456 Business Plaza, Suite 302',
      phone: '+1-555-0102',
      status: 'pending',
      eta: '11:15 AM',
      distance: '4.2 km'
    },
    {
      id: 'POD-2024-003',
      consignmentId: 'CNS-10003',
      customerName: 'Mike Chen',
      address: '789 Industrial Zone, Warehouse B',
      phone: '+1-555-0103',
      status: 'completed',
      eta: '09:45 AM',
      completedTime: '09:52 AM',
      distance: '1.8 km'
    },
    {
      id: 'POD-2024-004',
      consignmentId: 'CNS-10004',
      customerName: 'Emma Brown',
      address: '321 Retail Complex, Store 15',
      phone: '+1-555-0104',
      status: 'completed',
      eta: '10:00 AM',
      completedTime: '10:08 AM',
      distance: '3.1 km'
    }
  ]);

  const [selectedPOD, setSelectedPOD] = useState(null);
  const [activeTab, setActiveTabLocal] = useState('pods');
  const [podForm, setPodForm] = useState({
    signature: false,
    photo: false,
    notes: '',
    recipientName: '',
    recipientPhone: ''
  });

  // Submit POD form state
  const [submitPodConsId, setSubmitPodConsId] = useState('');
  const [submitPodReceivedBy, setSubmitPodReceivedBy] = useState('');
  const [submitPodReceiverContact, setSubmitPodReceiverContact] = useState('');
  const [submitPodRemarks, setSubmitPodRemarks] = useState('');
  const [submitPodFile, setSubmitPodFile] = useState(null);
  const [submitPodPreview, setSubmitPodPreview] = useState(null);
  const [submitPodSuccess, setSubmitPodSuccess] = useState(null);

  // Track list
  const [trackingData, setTrackingData] = useState([
    {
      id: 'TRK-2024-001',
      consignmentId: 'CNS-10005',
      status: 'in_transit',
      location: 'Main Hub - Downtown',
      lastUpdate: '2 mins ago',
      progress: 65
    },
    {
      id: 'TRK-2024-002',
      consignmentId: 'CNS-10006',
      status: 'pending',
      location: 'Sorting Center',
      lastUpdate: '15 mins ago',
      progress: 30
    }
  ]);

  const handlePODSubmit = () => {
    const updated = podList.map(p =>
      p.id === selectedPOD.id
        ? { ...p, status: 'completed', completedTime: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) }
        : p
    );
    setPodList(updated);
    setSelectedPOD(null);
    setPodForm({ signature: false, photo: false, notes: '', recipientName: '', recipientPhone: '' });
    
    // Update stats
    setDriverStats(prev => ({
      ...prev,
      completedToday: prev.completedToday + 1,
      pendingPODs: prev.pendingPODs - 1
    }));
  };

  // Handle file upload for Submit POD form
  const handleSubmitPodFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSubmitPodFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setSubmitPodPreview(reader.result);
    reader.readAsDataURL(file);
  };

  // Submit POD handler
  const handleSubmitPod = (e) => {
    e.preventDefault();
    if (!submitPodConsId.trim() || !submitPodReceivedBy || !submitPodReceiverContact) {
      alert('Please fill in all required fields');
      return;
    }
    // Simulate successful submission
    setSubmitPodSuccess({
      consignmentId: submitPodConsId,
      receivedBy: submitPodReceivedBy,
      timestamp: new Date().toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    });
    // Reset form after 3 seconds
    setTimeout(() => {
      setSubmitPodConsId('');
      setSubmitPodReceivedBy('');
      setSubmitPodReceiverContact('');
      setSubmitPodRemarks('');
      setSubmitPodFile(null);
      setSubmitPodPreview(null);
      setSubmitPodSuccess(null);
    }, 2000);
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)' }}>
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)',
        color: '#fff',
        padding: '28px 32px',
        boxShadow: '0 4px 12px rgba(30, 58, 138, 0.15)'
      }}>
        <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 32, alignItems: 'center' }}>
            {/* Left side - Driver Info */}
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
                <div style={{
                  background: 'rgba(255, 255, 255, 0.2)',
                  padding: 10,
                  borderRadius: 10,
                  display: 'flex', alignItems: 'center', justifyContent: 'center'
                }}>
                  <Truck size={24} color="#fff" />
                </div>
                <div>
                  <h1 style={{ fontSize: '1.75rem', fontWeight: 800, margin: 0 }}>Driver Portal</h1>
                  <p style={{ fontSize: '0.9rem', opacity: 0.9, margin: 0 }}>Manage deliveries and proof of delivery</p>
                </div>
              </div>
              
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
                <div>
                  <p style={{ fontSize: '0.75rem', opacity: 0.8, textTransform: 'uppercase', fontWeight: 700, marginBottom: 4 }}>Driver</p>
                  <p style={{ fontSize: '0.95rem', fontWeight: 600 }}>{driverInfo.name}</p>
                </div>
                <div>
                  <p style={{ fontSize: '0.75rem', opacity: 0.8, textTransform: 'uppercase', fontWeight: 700, marginBottom: 4 }}>Vehicle</p>
                  <p style={{ fontSize: '0.95rem', fontWeight: 600 }}>{driverInfo.vehicleNo}</p>
                </div>
                <div>
                  <p style={{ fontSize: '0.75rem', opacity: 0.8, textTransform: 'uppercase', fontWeight: 700, marginBottom: 4 }}>Route</p>
                  <p style={{ fontSize: '0.95rem', fontWeight: 600 }}>{driverInfo.route}</p>
                </div>
                <div>
                  <p style={{ fontSize: '0.75rem', opacity: 0.8, textTransform: 'uppercase', fontWeight: 700, marginBottom: 4 }}>Shift</p>
                  <p style={{ fontSize: '0.95rem', fontWeight: 600 }}>{driverInfo.shiftStart} - {driverInfo.shiftEnd}</p>
                </div>
              </div>
            </div>

            {/* Right side - Quick Stats */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
              <div style={{ background: 'rgba(255, 255, 255, 0.15)', padding: '14px 16px', borderRadius: 10, backdropFilter: 'blur(10px)' }}>
                <p style={{ fontSize: '0.8rem', opacity: 0.85, margin: 0, marginBottom: 4 }}>Completions</p>
                <p style={{ fontSize: '1.4rem', fontWeight: 800, margin: 0 }}>{driverStats.completedToday}/{driverStats.todayDeliveries}</p>
              </div>
              <div style={{ background: 'rgba(255, 255, 255, 0.15)', padding: '14px 16px', borderRadius: 10, backdropFilter: 'blur(10px)' }}>
                <p style={{ fontSize: '0.8rem', opacity: 0.85, margin: 0, marginBottom: 4 }}>Completion Rate</p>
                <p style={{ fontSize: '1.4rem', fontWeight: 800, margin: 0 }}>{driverStats.completionRate}%</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div style={{
        background: '#fff',
        borderBottom: '1px solid #e2e8f0',
        padding: '0 32px',
        display: 'flex', gap: 32
      }}>
        <div style={{ maxWidth: '1400px', margin: '0 auto', width: '100%', display: 'flex', gap: 32 }}>
          {[
            { id: 'pods', label: 'POD Management', icon: FileText },
            { id: 'submit-pod', label: 'Submit POD', icon: Upload },
            { id: 'tracking', label: 'Track Deliveries', icon: MapPin }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTabLocal(tab.id)}
                style={{
                  flex: 1,
                  padding: '16px 0',
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  fontSize: '0.95rem',
                  fontWeight: 600,
                  color: activeTab === tab.id ? '#1e3a8a' : '#94a3b8',
                  borderBottom: activeTab === tab.id ? '3px solid #3b82f6' : 'none',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                  transition: 'all 0.2s'
                }}
              >
                <Icon size={18} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <div style={{ padding: '32px', maxWidth: '1400px', margin: '0 auto' }}>
        
        {/* POD MANAGEMENT TAB */}
        {activeTab === 'pods' && (
          <div style={{ display: 'grid', gridTemplateColumns: selectedPOD ? '1fr 420px' : '1fr', gap: 24 }}>
            
            {/* POD List */}
            <div style={{
              background: '#fff',
              borderRadius: 16,
              border: '1px solid #e2e8f0',
              overflow: 'hidden',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)'
            }}>
              <div style={{
                padding: '20px 24px',
                borderBottom: '1px solid #e2e8f0',
                background: '#f8fafc',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between'
              }}>
                <div>
                  <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#1e3a8a', margin: 0 }}>Proof of Delivery</h3>
                  <p style={{ fontSize: '0.8rem', color: '#64748b', margin: 0, marginTop: 4 }}>
                    {driverStats.pendingPODs} pending • {driverStats.completedToday} completed
                  </p>
                </div>
                <button style={{
                  padding: '8px 16px',
                  background: '#3b82f6',
                  color: '#fff',
                  border: 'none',
                  borderRadius: 8,
                  cursor: 'pointer',
                  fontWeight: 600,
                  fontSize: '0.85rem',
                  display: 'flex', alignItems: 'center', gap: 6
                }}>
                  <RefreshCw size={14} /> Refresh
                </button>
              </div>

              <div style={{ padding: '8px 0' }}>
                {podList.map((pod, idx) => (
                  <div
                    key={pod.id}
                    onClick={() => pod.status === 'pending' && setSelectedPOD(pod)}
                    style={{
                      padding: '16px 20px',
                      borderBottom: idx < podList.length - 1 ? '1px solid #f1f5f9' : 'none',
                      cursor: pod.status === 'pending' ? 'pointer' : 'default',
                      background: pod.status === 'completed' ? '#f0f9ff' : selectedPOD?.id === pod.id ? '#eff6ff' : '#fff',
                      borderLeft: pod.status === 'completed' ? '4px solid #10b981' : selectedPOD?.id === pod.id ? '4px solid #3b82f6' : '4px solid transparent',
                      transition: 'all 0.2s'
                    }}
                    onMouseEnter={e => { if (pod.status === 'pending') e.currentTarget.style.background = '#f8fafc'; }}
                    onMouseLeave={e => { if (pod.status === 'pending') e.currentTarget.style.background = selectedPOD?.id === pod.id ? '#eff6ff' : '#fff'; }}
                  >
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16 }}>
                      <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 10,
                        background: pod.status === 'completed' ? '#dcfce7' : '#dbeafe',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        flexShrink: 0
                      }}>
                        {pod.status === 'completed' ? (
                          <CheckCircle2 size={20} color="#10b981" />
                        ) : (
                          <Package size={20} color="#3b82f6" />
                        )}
                      </div>
                      
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                          <span style={{
                            fontSize: '0.75rem',
                            fontWeight: 700,
                            background: '#f1f5f9',
                            color: '#475569',
                            padding: '2px 8px',
                            borderRadius: 4
                          }}>
                            {pod.id}
                          </span>
                          <span style={{
                            fontSize: '0.7rem',
                            fontWeight: 700,
                            background: pod.status === 'completed' ? '#d1fae5' : '#fef3c7',
                            color: pod.status === 'completed' ? '#065f46' : '#b45309',
                            padding: '2px 8px',
                            borderRadius: 999,
                            textTransform: 'uppercase'
                          }}>
                            {pod.status === 'completed' ? 'Delivered' : 'Pending'}
                          </span>
                        </div>
                        
                        <p style={{ fontSize: '0.95rem', fontWeight: 600, color: '#1e293b', margin: 0, marginBottom: 4 }}>
                          {pod.customerName}
                        </p>
                        
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: '0.8rem', color: '#64748b' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                            <MapPin size={14} />
                            <span>{pod.address}</span>
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                            <Phone size={14} />
                            <span>{pod.phone}</span>
                          </div>
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginTop: 8, fontSize: '0.8rem' }}>
                          <div>
                            <p style={{ color: '#94a3b8', margin: 0, marginBottom: 2 }}>ETA</p>
                            <p style={{ color: '#1e293b', margin: 0, fontWeight: 600 }}>{pod.eta}</p>
                          </div>
                          <div>
                            <p style={{ color: '#94a3b8', margin: 0, marginBottom: 2 }}>Distance</p>
                            <p style={{ color: '#1e293b', margin: 0, fontWeight: 600 }}>{pod.distance}</p>
                          </div>
                          {pod.status === 'completed' && (
                            <div>
                              <p style={{ color: '#94a3b8', margin: 0, marginBottom: 2 }}>Completed</p>
                              <p style={{ color: '#10b981', margin: 0, fontWeight: 600 }}>{pod.completedTime}</p>
                            </div>
                          )}
                        </div>
                      </div>

                      {pod.status === 'pending' && (
                        <ChevronRight size={20} color="#94a3b8" style={{ flexShrink: 0, marginTop: 4 }} />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* POD Form */}
            {selectedPOD && (
              <div style={{
                background: '#fff',
                borderRadius: 16,
                border: '1px solid #e2e8f0',
                overflow: 'hidden',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)',
                display: 'flex', flexDirection: 'column'
              }}>
                <div style={{
                  padding: '16px 20px',
                  background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)',
                  color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between'
                }}>
                  <div>
                    <h4 style={{ fontSize: '0.95rem', fontWeight: 700, margin: 0, marginBottom: 4 }}>Submit POD</h4>
                    <p style={{ fontSize: '0.8rem', opacity: 0.9, margin: 0 }}>{selectedPOD.customerName}</p>
                  </div>
                  <button
                    onClick={() => setSelectedPOD(null)}
                    style={{
                      background: 'rgba(255, 255, 255, 0.2)',
                      border: 'none',
                      color: '#fff',
                      width: 32,
                      height: 32,
                      borderRadius: 8,
                      cursor: 'pointer',
                      fontSize: '1.2rem',
                      display: 'flex', alignItems: 'center', justifyContent: 'center'
                    }}
                  >
                    ✕
                  </button>
                </div>

                <div style={{ flex: 1, overflowY: 'auto', padding: '20px' }}>
                  <div style={{ marginBottom: 18 }}>
                    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 700, color: '#1e3a8a', textTransform: 'uppercase', marginBottom: 6 }}>
                      Recipient Name *
                    </label>
                    <input
                      type="text"
                      placeholder="Full name of recipient"
                      value={podForm.recipientName}
                      onChange={e => setPodForm({ ...podForm, recipientName: e.target.value })}
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        border: '1.5px solid #e2e8f0',
                        borderRadius: 8,
                        fontSize: '0.9rem',
                        fontFamily: 'inherit',
                        outline: 'none',
                        transition: 'all 0.2s'
                      }}
                      onFocus={e => e.target.style.borderColor = '#3b82f6'}
                      onBlur={e => e.target.style.borderColor = '#e2e8f0'}
                    />
                  </div>

                  <div style={{ marginBottom: 18 }}>
                    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 700, color: '#1e3a8a', textTransform: 'uppercase', marginBottom: 6 }}>
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      placeholder="Contact number"
                      value={podForm.recipientPhone}
                      onChange={e => setPodForm({ ...podForm, recipientPhone: e.target.value })}
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        border: '1.5px solid #e2e8f0',
                        borderRadius: 8,
                        fontSize: '0.9rem',
                        fontFamily: 'inherit',
                        outline: 'none',
                        transition: 'all 0.2s'
                      }}
                      onFocus={e => e.target.style.borderColor = '#3b82f6'}
                      onBlur={e => e.target.style.borderColor = '#e2e8f0'}
                    />
                  </div>

                  <div style={{ marginBottom: 18 }}>
                    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 700, color: '#1e3a8a', textTransform: 'uppercase', marginBottom: 6 }}>
                      Delivery Notes
                    </label>
                    <textarea
                      placeholder="Any special instructions..."
                      value={podForm.notes}
                      onChange={e => setPodForm({ ...podForm, notes: e.target.value })}
                      rows={3}
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        border: '1.5px solid #e2e8f0',
                        borderRadius: 8,
                        fontSize: '0.9rem',
                        fontFamily: 'inherit',
                        outline: 'none',
                        transition: 'all 0.2s',
                        resize: 'none'
                      }}
                      onFocus={e => e.target.style.borderColor = '#3b82f6'}
                      onBlur={e => e.target.style.borderColor = '#e2e8f0'}
                    />
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 18 }}>
                    <label style={{
                      padding: '12px',
                      border: '2px dashed #bfdbfe',
                      borderRadius: 10,
                      background: podForm.photo ? '#eff6ff' : '#f8fafc',
                      cursor: 'pointer',
                      textAlign: 'center',
                      transition: 'all 0.2s'
                    }} onMouseEnter={e => e.currentTarget.style.borderColor = '#3b82f6'} onMouseLeave={e => e.currentTarget.style.borderColor = '#bfdbfe'}>
                      <Camera size={18} color={podForm.photo ? '#3b82f6' : '#94a3b8'} style={{ margin: '0 auto 6px', display: 'block' }} />
                      <span style={{ fontSize: '0.8rem', fontWeight: 600, color: podForm.photo ? '#3b82f6' : '#64748b', display: 'block' }}>
                        {podForm.photo ? '✓ Photo' : 'Upload Photo'}
                      </span>
                      <input type="file" accept="image/*" style={{ display: 'none' }} onChange={() => setPodForm({ ...podForm, photo: true })} />
                    </label>

                    <label style={{
                      padding: '12px',
                      border: '2px dashed #bfdbfe',
                      borderRadius: 10,
                      background: podForm.signature ? '#eff6ff' : '#f8fafc',
                      cursor: 'pointer',
                      textAlign: 'center',
                      transition: 'all 0.2s'
                    }} onMouseEnter={e => e.currentTarget.style.borderColor = '#3b82f6'} onMouseLeave={e => e.currentTarget.style.borderColor = '#bfdbfe'}>
                      <CheckSquare size={18} color={podForm.signature ? '#3b82f6' : '#94a3b8'} style={{ margin: '0 auto 6px', display: 'block' }} />
                      <span style={{ fontSize: '0.8rem', fontWeight: 600, color: podForm.signature ? '#3b82f6' : '#64748b', display: 'block' }}>
                        {podForm.signature ? '✓ Signature' : 'Get Signature'}
                      </span>
                      <input type="checkbox" style={{ display: 'none' }} onChange={() => setPodForm({ ...podForm, signature: !podForm.signature })} />
                    </label>
                  </div>

                  <div style={{
                    padding: '12px 14px',
                    background: '#fef3c7',
                    border: '1px solid #fcd34d',
                    borderRadius: 8,
                    display: 'flex', gap: 10, alignItems: 'flex-start'
                  }}>
                    <AlertCircle size={16} color="#b45309" style={{ flexShrink: 0, marginTop: 2 }} />
                    <span style={{ fontSize: '0.75rem', color: '#92400e' }}>
                      All fields must be completed before submission
                    </span>
                  </div>
                </div>

                <div style={{
                  padding: '16px 20px',
                  borderTop: '1px solid #e2e8f0',
                  display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12
                }}>
                  <button
                    onClick={() => setSelectedPOD(null)}
                    style={{
                      padding: '10px 16px',
                      background: '#f1f5f9',
                      border: '1px solid #e2e8f0',
                      borderRadius: 8,
                      fontWeight: 600,
                      cursor: 'pointer',
                      color: '#475569',
                      transition: 'all 0.2s'
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = '#e2e8f0'}
                    onMouseLeave={e => e.currentTarget.style.background = '#f1f5f9'}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handlePODSubmit}
                    disabled={!podForm.recipientName || !podForm.recipientPhone || !podForm.photo || !podForm.signature}
                    style={{
                      padding: '10px 16px',
                      background: (!podForm.recipientName || !podForm.recipientPhone || !podForm.photo || !podForm.signature) ? '#cbd5e1' : '#3b82f6',
                      border: 'none',
                      borderRadius: 8,
                      color: '#fff',
                      fontWeight: 600,
                      cursor: (!podForm.recipientName || !podForm.recipientPhone || !podForm.photo || !podForm.signature) ? 'not-allowed' : 'pointer',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                      transition: 'all 0.2s'
                    }}
                    onMouseEnter={e => { if (!(!podForm.recipientName || !podForm.recipientPhone || !podForm.photo || !podForm.signature)) e.currentTarget.style.background = '#2563eb'; }}
                    onMouseLeave={e => { if (!(!podForm.recipientName || !podForm.recipientPhone || !podForm.photo || !podForm.signature)) e.currentTarget.style.background = '#3b82f6'; }}
                  >
                    <Upload size={14} /> Submit POD
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* SUBMIT POD TAB */}
        {activeTab === 'submit-pod' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
            
            {/* Submit POD Form */}
            <div style={{
              background: '#fff',
              borderRadius: 16,
              border: '1px solid #e2e8f0',
              overflow: 'hidden',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)'
            }}>
              <div style={{
                padding: '20px 24px',
                borderBottom: '1px solid #e2e8f0',
                background: '#f8fafc'
              }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#1e3a8a', margin: 0 }}>Submit Proof of Delivery</h3>
                <p style={{ fontSize: '0.8rem', color: '#64748b', margin: 0, marginTop: 4 }}>
                  Record delivery with recipient details and documentation
                </p>
              </div>

              <div style={{ padding: '24px' }}>
                <form onSubmit={handleSubmitPod}>
                  <div style={{ marginBottom: 20 }}>
                    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 700, color: '#1e3a8a', textTransform: 'uppercase', marginBottom: 8 }}>
                      Consignment Tracking ID *
                    </label>
                    <input
                      type="text"
                      className="form-input"
                      value={submitPodConsId}
                      onChange={e => setSubmitPodConsId(e.target.value)}
                      placeholder="e.g. CON-982103"
                      required
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        border: '1.5px solid #e2e8f0',
                        borderRadius: 8,
                        fontSize: '0.9rem',
                        fontFamily: 'inherit',
                        outline: 'none'
                      }}
                    />
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 700, color: '#1e3a8a', textTransform: 'uppercase', marginBottom: 8 }}>
                        Received By *
                      </label>
                      <input
                        type="text"
                        value={submitPodReceivedBy}
                        onChange={e => setSubmitPodReceivedBy(e.target.value)}
                        placeholder="Recipient full name"
                        required
                        style={{
                          width: '100%',
                          padding: '10px 12px',
                          border: '1.5px solid #e2e8f0',
                          borderRadius: 8,
                          fontSize: '0.9rem',
                          fontFamily: 'inherit',
                          outline: 'none'
                        }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 700, color: '#1e3a8a', textTransform: 'uppercase', marginBottom: 8 }}>
                        Contact Number *
                      </label>
                      <input
                        type="tel"
                        value={submitPodReceiverContact}
                        onChange={e => setSubmitPodReceiverContact(e.target.value)}
                        placeholder="+1 212 555 0100"
                        required
                        style={{
                          width: '100%',
                          padding: '10px 12px',
                          border: '1.5px solid #e2e8f0',
                          borderRadius: 8,
                          fontSize: '0.9rem',
                          fontFamily: 'inherit',
                          outline: 'none'
                        }}
                      />
                    </div>
                  </div>

                  <div style={{ marginBottom: 20 }}>
                    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 700, color: '#1e3a8a', textTransform: 'uppercase', marginBottom: 8 }}>
                      Delivery Remarks
                    </label>
                    <textarea
                      value={submitPodRemarks}
                      onChange={e => setSubmitPodRemarks(e.target.value)}
                      placeholder="e.g. Delivered to front desk, package intact"
                      rows={3}
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        border: '1.5px solid #e2e8f0',
                        borderRadius: 8,
                        fontSize: '0.9rem',
                        fontFamily: 'inherit',
                        outline: 'none',
                        resize: 'none'
                      }}
                    />
                  </div>

                  <div style={{ marginBottom: 20 }}>
                    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 700, color: '#1e3a8a', textTransform: 'uppercase', marginBottom: 8 }}>
                      Signature / Delivery Photo
                    </label>
                    <div
                      style={{
                        border: '2px dashed #bfdbfe',
                        borderRadius: 10,
                        padding: 20,
                        textAlign: 'center',
                        background: '#f8fafc',
                        cursor: 'pointer',
                        transition: 'all 0.2s'
                      }}
                      onDragOver={e => e.preventDefault()}
                      onDrop={e => { e.preventDefault(); const f = e.dataTransfer.files?.[0]; if (f) handleSubmitPodFile({ target: { files: [f] } }); }}
                    >
                      {submitPodPreview ? (
                        <div style={{ position: 'relative', display: 'inline-block' }}>
                          <img src={submitPodPreview} alt="POD preview" style={{ maxHeight: 160, maxWidth: '100%', borderRadius: 8, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }} />
                          <button
                            type="button"
                            onClick={() => { setSubmitPodFile(null); setSubmitPodPreview(null); }}
                            style={{ position: 'absolute', top: -8, right: -8, background: '#ef4444', color: '#fff', border: 'none', borderRadius: '50%', width: 22, height: 22, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                          >
                            <X size={12} />
                          </button>
                        </div>
                      ) : (
                        <label htmlFor="submit-pod-file-input" style={{ cursor: 'pointer', display: 'block' }}>
                          <div style={{ fontSize: '2rem', marginBottom: 6 }}>📷</div>
                          <p style={{ fontWeight: 600, color: '#1e3a8a', marginBottom: 4, margin: '0 0 4px 0' }}>Click to upload or drag & drop</p>
                          <p style={{ fontSize: '0.8rem', color: '#64748b', margin: '0 0 12px 0' }}>PNG, JPG, PDF — Max 5MB</p>
                          <div style={{ display: 'flex', gap: 10, justifyContent: 'center', marginTop: 12 }}>
                            <label htmlFor="submit-pod-file-input" style={{ padding: '7px 14px', background: '#3b82f6', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: '0.8rem', fontWeight: 600 }}>
                              📁 Choose File
                            </label>
                            <label htmlFor="submit-pod-camera-input" style={{ padding: '7px 14px', background: '#3b82f6', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: '0.8rem', fontWeight: 600 }}>
                              📷 Use Camera
                            </label>
                          </div>
                        </label>
                      )}
                      <input id="submit-pod-file-input" type="file" accept="image/*,application/pdf" onChange={handleSubmitPodFile} style={{ display: 'none' }} />
                      <input id="submit-pod-camera-input" type="file" accept="image/*" capture="environment" onChange={handleSubmitPodFile} style={{ display: 'none' }} />
                    </div>
                  </div>

                  {submitPodSuccess ? (
                    <div style={{ textAlign: 'center', padding: '24px 0' }}>
                      <CheckCircle2 size={48} color="#10b981" style={{ marginBottom: 12, display: 'block' }} />
                      <p style={{ fontWeight: 700, color: '#10b981', margin: 0, marginBottom: 4 }}>POD Recorded Successfully!</p>
                      <p style={{ fontSize: '0.8rem', color: '#64748b', margin: 0 }}>Consignment {submitPodSuccess.consignmentId} marked as delivered</p>
                      <p style={{ fontSize: '0.75rem', color: '#94a3b8', margin: '8px 0 0 0' }}>{submitPodSuccess.timestamp}</p>
                    </div>
                  ) : (
                    <button
                      type="submit"
                      style={{
                        width: '100%',
                        padding: '12px 16px',
                        background: (!submitPodConsId.trim() || !submitPodReceivedBy || !submitPodReceiverContact) ? '#cbd5e1' : '#3b82f6',
                        border: 'none',
                        borderRadius: 8,
                        color: '#fff',
                        fontWeight: 600,
                        cursor: (!submitPodConsId.trim() || !submitPodReceivedBy || !submitPodReceiverContact) ? 'not-allowed' : 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: 8,
                        fontSize: '0.9rem',
                        transition: 'all 0.2s'
                      }}
                    >
                      <Upload size={16} /> Submit Proof of Delivery
                    </button>
                  )}
                </form>
              </div>
            </div>

            {/* POD Requirements */}
            <div style={{
              background: '#fff',
              borderRadius: 16,
              border: '1px solid #e2e8f0',
              padding: '24px',
              height: 'fit-content',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)'
            }}>
              <h4 style={{ fontWeight: 700, marginBottom: 16, fontSize: '0.95rem', color: '#1e3a8a', margin: 0 }}>POD Requirements</h4>
              <ul style={{ paddingLeft: 18, display: 'flex', flexDirection: 'column', gap: 12, fontSize: '0.85rem', color: '#64748b', margin: 0 }}>
                <li style={{ lineHeight: 1.4 }}>Enter the exact <strong>Consignment Tracking ID</strong></li>
                <li style={{ lineHeight: 1.4 }}>Provide <strong>recipient name</strong> and <strong>contact</strong></li>
                <li style={{ lineHeight: 1.4 }}>Upload a clear <strong>delivery photo/signature</strong></li>
                <li style={{ lineHeight: 1.4 }}>On mobile, use the <strong>camera option</strong> for capture</li>
                <li style={{ lineHeight: 1.4 }}>System automatically marks as <strong>DELIVERED</strong></li>
                <li style={{ lineHeight: 1.4 }}>All fields marked with <strong>*</strong> are required</li>
              </ul>
              
              <div style={{
                marginTop: 20,
                padding: 16,
                background: '#dbeafe',
                border: '1px solid #bfdbfe',
                borderRadius: 10
              }}>
                <p style={{ fontSize: '0.8rem', color: '#1e40af', margin: 0, fontWeight: 600 }}>💡 Tip</p>
                <p style={{ fontSize: '0.75rem', color: '#1e40af', margin: '6px 0 0 0' }}>For better accuracy, capture photos in good lighting and ensure recipient contact is correct</p>
              </div>
            </div>
          </div>
        )}

        {/* TRACKING TAB */}
        {activeTab === 'tracking' && (
          <div style={{
            background: '#fff',
            borderRadius: 16,
            border: '1px solid #e2e8f0',
            overflow: 'hidden',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)'
          }}>
            <div style={{
              padding: '20px 24px',
              borderBottom: '1px solid #e2e8f0',
              background: '#f8fafc',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between'
            }}>
              <div>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#1e3a8a', margin: 0 }}>Track Deliveries</h3>
                <p style={{ fontSize: '0.8rem', color: '#64748b', margin: 0, marginTop: 4 }}>Real-time location tracking</p>
              </div>
            </div>

            <div style={{ padding: '24px' }}>
              <div style={{ display: 'grid', gap: 20 }}>
                {trackingData.map(track => (
                  <div key={track.id} style={{
                    padding: '20px',
                    background: '#f8fafc',
                    borderRadius: 12,
                    border: '1px solid #e2e8f0'
                  }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 16, marginBottom: 16 }}>
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                          <span style={{
                            fontSize: '0.75rem',
                            fontWeight: 700,
                            background: '#f1f5f9',
                            color: '#475569',
                            padding: '2px 8px',
                            borderRadius: 4
                          }}>
                            {track.id}
                          </span>
                          <span style={{
                            fontSize: '0.7rem',
                            fontWeight: 700,
                            background: track.status === 'in_transit' ? '#dcfce7' : '#fef3c7',
                            color: track.status === 'in_transit' ? '#065f46' : '#b45309',
                            padding: '2px 8px',
                            borderRadius: 999,
                            textTransform: 'uppercase'
                          }}>
                            {track.status === 'in_transit' ? 'In Transit' : 'Pending'}
                          </span>
                        </div>
                        <p style={{ fontSize: '0.9rem', fontWeight: 600, color: '#1e293b', margin: 0 }}>
                          CNS: {track.consignmentId}
                        </p>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <p style={{ fontSize: '0.8rem', color: '#64748b', margin: 0, marginBottom: 4 }}>Last Update</p>
                        <p style={{ fontSize: '0.9rem', fontWeight: 600, color: '#1e293b', margin: 0 }}>{track.lastUpdate}</p>
                      </div>
                    </div>

                    <div style={{ marginBottom: 16 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                        <Navigation size={16} color="#3b82f6" />
                        <span style={{ fontSize: '0.9rem', color: '#475569' }}>{track.location}</span>
                      </div>
                      <div style={{
                        width: '100%',
                        height: 8,
                        background: '#e2e8f0',
                        borderRadius: 999,
                        overflow: 'hidden'
                      }}>
                        <div style={{
                          width: `${track.progress}%`,
                          height: '100%',
                          background: 'linear-gradient(90deg, #3b82f6, #1e40af)',
                          transition: 'width 0.3s ease'
                        }} />
                      </div>
                      <p style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: 6, margin: 0 }}>
                        {track.progress}% complete
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
