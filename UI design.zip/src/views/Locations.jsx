import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import {
  MapPin, Plus, Pencil, Trash2, CheckCircle2, X,
  Globe, Building2, ChevronDown
} from 'lucide-react';

const EMPTY_FORM = {
  locationCode: '', name: '', type: 'HUB',
  city: '', country: '', latitude: '', longitude: ''
};

const TYPE_COLORS = {
  HUB:                 'badge-admin',
  SORTING_CENTER:      'badge-info',
  DISTRIBUTION_CENTER: 'badge-success',
  GATEWAY:             'badge-warning',
};

export default function Locations() {
  const [locations, setLocations]   = useState([]);
  const [loading, setLoading]       = useState(false);
  const [showModal, setShowModal]   = useState(false);
  const [editingRow, setEditingRow] = useState(null);   // null = create, else location obj
  const [form, setForm]             = useState(EMPTY_FORM);
  const [saving, setSaving]         = useState(false);
  const [saveError, setSaveError]   = useState(null);
  const [saveOk, setSaveOk]         = useState(false);
  const [deleteId, setDeleteId]     = useState(null);

  const fetchLocations = async () => {
    setLoading(true);
    try { setLocations(await api.getLocations()); }
    catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchLocations(); }, []);

  const openCreate = () => {
    setEditingRow(null);
    setForm(EMPTY_FORM);
    setSaveError(null); setSaveOk(false);
    setShowModal(true);
  };

  const openEdit = (loc) => {
    setEditingRow(loc);
    setForm({
      locationCode: loc.locationCode || '',
      name:         loc.name         || '',
      type:         loc.type         || 'HUB',
      city:         loc.city         || '',
      country:      loc.country      || '',
      latitude:     loc.latitude     || '',
      longitude:    loc.longitude    || '',
    });
    setSaveError(null); setSaveOk(false);
    setShowModal(true);
  };

  const handleFormChange = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true); setSaveError(null); setSaveOk(false);
    try {
      const payload = {
        ...form,
        latitude:  parseFloat(form.latitude)  || 0,
        longitude: parseFloat(form.longitude) || 0,
      };
      if (editingRow) {
        await api.updateLocation({ ...payload, locationCode: editingRow.locationCode });
      } else {
        await api.createLocation(payload);
      }
      setSaveOk(true);
      await fetchLocations();
      setTimeout(() => { setShowModal(false); setSaveOk(false); }, 1200);
    } catch (err) {
      setSaveError(err.message || 'Save failed.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (locationCode) => {
    if (!window.confirm(`Delete location ${locationCode}?`)) return;
    setDeleteId(locationCode);
    try {
      // Mock: remove from store
      const store = api.getMockStore();
      store.locations = store.locations.filter(l => l.locationCode !== locationCode);
      await fetchLocations();
    } finally {
      setDeleteId(null);
    }
  };

  const fmt = (v) => v ? String(v) : '—';
  const fmtDate = (v) => v ? new Date(v).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : '—';

  return (
    <div className="page-container animate-slideup">

      {/* Header */}
      <div className="page-header">
        <div>
          <h2 className="page-title"><Globe size={22} color="var(--primary)" /> Hub Locations</h2>
          <p className="page-subtitle">Manage registered logistics hubs, warehouses, and sorting centers.</p>
        </div>
        <button className="btn btn-primary" onClick={openCreate}>
          <Plus size={15} /> Register New Hub
        </button>
      </div>

      {/* Table Card */}
      <div className="section-card">
        <div className="section-card-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Building2 size={16} color="var(--text-secondary)" />
            <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>
              All Locations
            </span>
            <span style={{
              background: '#f1f5f9', color: 'var(--text-secondary)',
              padding: '2px 8px', borderRadius: '999px', fontSize: '0.75rem', fontWeight: 600
            }}>{locations.length}</span>
          </div>
        </div>

        <div className="table-wrapper">
          <table className="data-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Code</th>
                <th>Name</th>
                <th>Type</th>
                <th>City</th>
                <th>Country</th>
                <th>Latitude</th>
                <th>Longitude</th>
                <th>Created Date</th>
                <th>Created By</th>
                <th>Updated Date</th>
                <th>Updated By</th>
                <th style={{ textAlign: 'center' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={13} style={{ textAlign: 'center', padding: '40px', color: 'var(--text-muted)' }}>
                  Loading locations…
                </td></tr>
              ) : locations.length === 0 ? (
                <tr><td colSpan={13} style={{ textAlign: 'center', padding: '40px', color: 'var(--text-muted)' }}>
                  No locations registered yet.
                </td></tr>
              ) : locations.map((loc, i) => (
                <tr key={loc.locationCode}>
                  <td style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>
                    {loc.id || i + 1}
                  </td>
                  <td>
                    <span className="code-tag">{loc.locationCode}</span>
                  </td>
                  <td style={{ fontWeight: 500 }}>{fmt(loc.name || loc.city)}</td>
                  <td>
                    <span className={`badge ${TYPE_COLORS[loc.type] || 'badge-info'}`}>
                      {(loc.type || '').replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td>{fmt(loc.city)}</td>
                  <td>{fmt(loc.country)}</td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.78rem' }}>
                    {loc.latitude != null ? Number(loc.latitude).toFixed(4) : '—'}
                  </td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.78rem' }}>
                    {loc.longitude != null ? Number(loc.longitude).toFixed(4) : '—'}
                  </td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{fmtDate(loc.createdDate)}</td>
                  <td style={{ fontSize: '0.8rem' }}>{fmt(loc.createdBy)}</td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{fmtDate(loc.updatedDate)}</td>
                  <td style={{ fontSize: '0.8rem' }}>{fmt(loc.updatedBy)}</td>
                  <td>
                    <div style={{ display: 'flex', gap: '6px', justifyContent: 'center' }}>
                      <button className="btn-icon edit" title="Edit" onClick={() => openEdit(loc)}>
                        <Pencil size={14} />
                      </button>
                      <button
                        className="btn-icon delete"
                        title="Delete"
                        onClick={() => handleDelete(loc.locationCode)}
                        disabled={deleteId === loc.locationCode}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal-box animate-slideup">
            <div className="modal-header">
              <h3 style={{ fontSize: '1.1rem' }}>
                {editingRow ? `Edit — ${editingRow.locationCode}` : 'Register New Hub'}
              </h3>
              <button className="btn-icon" onClick={() => setShowModal(false)}><X size={16} /></button>
            </div>

            {saveOk ? (
              <div style={{ textAlign: 'center', padding: '32px 0' }}>
                <CheckCircle2 size={44} color="var(--success)" style={{ marginBottom: 10 }} />
                <p style={{ fontWeight: 700, color: 'var(--success)' }}>Saved successfully!</p>
              </div>
            ) : (
              <form onSubmit={handleSave}>
                <div className="grid-cols-2">
                  <div className="form-group">
                    <label className="form-label">Location Code</label>
                    <input className="form-input code-tag" value={form.locationCode}
                      onChange={e => handleFormChange('locationCode', e.target.value)}
                      placeholder="e.g. LOC005" disabled={!!editingRow} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Hub Name</label>
                    <input className="form-input" value={form.name}
                      onChange={e => handleFormChange('name', e.target.value)}
                      placeholder="e.g. New York Central Hub" />
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Facility Type</label>
                  <select className="form-select" value={form.type}
                    onChange={e => handleFormChange('type', e.target.value)}>
                    <option value="HUB">HUB — Central Terminal</option>
                    <option value="SORTING_CENTER">SORTING_CENTER — Conveyor Sorting</option>
                    <option value="DISTRIBUTION_CENTER">DISTRIBUTION_CENTER — Delivery Hub</option>
                    <option value="GATEWAY">GATEWAY — International Border</option>
                  </select>
                </div>

                <div className="grid-cols-2">
                  <div className="form-group">
                    <label className="form-label">City</label>
                    <input className="form-input" value={form.city}
                      onChange={e => handleFormChange('city', e.target.value)}
                      placeholder="e.g. Tokyo" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Country</label>
                    <input className="form-input" value={form.country}
                      onChange={e => handleFormChange('country', e.target.value)}
                      placeholder="e.g. Japan" required />
                  </div>
                </div>

                <div className="grid-cols-2">
                  <div className="form-group">
                    <label className="form-label">GPS Latitude</label>
                    <input type="number" step="0.0001" className="form-input" value={form.latitude}
                      onChange={e => handleFormChange('latitude', e.target.value)}
                      placeholder="e.g. 35.6762" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">GPS Longitude</label>
                    <input type="number" step="0.0001" className="form-input" value={form.longitude}
                      onChange={e => handleFormChange('longitude', e.target.value)}
                      placeholder="e.g. 139.6503" required />
                  </div>
                </div>

                {saveError && (
                  <div style={{ padding: '10px 14px', background: 'var(--danger-bg)', border: '1px solid #fca5a5', borderRadius: 8, color: 'var(--danger)', fontSize: '0.85rem', marginBottom: 14 }}>
                    {saveError}
                  </div>
                )}

                <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 4 }}>
                  <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                  <button type="submit" className="btn btn-primary" disabled={saving}>
                    {saving ? 'Saving…' : editingRow ? 'Save Changes' : 'Register Hub'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
