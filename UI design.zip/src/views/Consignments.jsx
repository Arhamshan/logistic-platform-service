import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import {
  Package, Plus, Pencil, Trash2, CheckCircle2, X,
  ArrowRight, ArrowLeft, FileCheck, Eye
} from 'lucide-react';

const STATUS_BADGE = {
  PENDING:    'badge-warning',
  IN_TRANSIT: 'badge-info',
  DELIVERED:  'badge-success',
  EXCEPTION:  'badge-danger',
};

export default function Consignments() {
  const [locations, setLocations]       = useState([]);
  const [consignments, setConsignments] = useState([]);
  const [activeTab, setActiveTab]       = useState('list'); // list | book | pod
  const [bookStep, setBookStep]         = useState(1);

  // Book form
  const [sourceHub, setSourceHub] = useState('');
  const [destHub, setDestHub]     = useState('');
  const [items, setItems]         = useState([{ barcode: '', weight: 1.0, dimensions: '15x10x10 cm' }]);
  const [bookLoading, setBookLoading] = useState(false);
  const [bookError, setBookError]     = useState(null);
  const [bookSuccess, setBookSuccess] = useState(null);

  // POD form
  const [podConsId, setPodConsId]         = useState('');
  const [receivedBy, setReceivedBy]       = useState('');
  const [receiverContact, setReceiverContact] = useState('');
  const [podRemarks, setPodRemarks]       = useState('');
  const [podFile, setPodFile]             = useState(null);       // actual File object
  const [podPreview, setPodPreview]       = useState(null);       // base64 preview URL
  const [podLoading, setPodLoading]       = useState(false);
  const [podError, setPodError]           = useState(null);
  const [podSuccess, setPodSuccess]       = useState(null);

  // Edit / Delete
  const [deleteId, setDeleteId] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [locs, store] = await Promise.all([api.getLocations(), Promise.resolve(api.getMockStore())]);
      setLocations(locs);
      setConsignments([...store.consignments]);
      if (locs.length > 1) { setSourceHub(locs[0].locationCode); setDestHub(locs[1].locationCode); }
      else if (locs.length === 1) { setSourceHub(locs[0].locationCode); setDestHub(locs[0].locationCode); }
    } catch (e) { console.error(e); }
  };

  /* ── Manifest helpers ── */
  const totalWeight = items.reduce((s, i) => s + (parseFloat(i.weight) || 0), 0);
  const addItem   = () => setItems(p => [...p, { barcode: `BAR-${Math.floor(10000 + Math.random() * 90000)}`, weight: 1.0, dimensions: '20x15x15 cm' }]);
  const removeItem = idx => setItems(p => p.filter((_, i) => i !== idx));
  const changeItem = (idx, k, v) => setItems(p => { const n = [...p]; n[idx] = { ...n[idx], [k]: v }; return n; });

  /* ── Stepper nav ── */
  const nextStep = () => {
    if (bookStep === 1 && sourceHub === destHub) { setBookError('Origin and Destination must differ.'); return; }
    setBookError(null);
    setBookStep(s => Math.min(3, s + 1));
  };
  const prevStep = () => setBookStep(s => Math.max(1, s - 1));

  /* ── Submit Booking ── */
  const handleBook = async () => {
    setBookLoading(true); setBookError(null);
    try {
      const res = await api.bookConsignment({ sourceLocation: sourceHub, destinationLocation: destHub, items });
      setBookSuccess(res);
      await loadData();
      setItems([{ barcode: `BAR-${Math.floor(10000 + Math.random() * 90000)}`, weight: 1.0, dimensions: '15x10x10 cm' }]);
    } catch (err) { setBookError(err.message || 'Booking failed.'); }
    finally { setBookLoading(false); }
  };

  /* ── POD photo handler ── */
  const handlePodFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPodFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setPodPreview(reader.result);
    reader.readAsDataURL(file);
  };

  /* ── Submit POD ── */
  const handlePod = async (e) => {
    e.preventDefault();
    setPodLoading(true); setPodError(null); setPodSuccess(null);
    try {
      // Use base64 preview or file name as podImage value
      const podImage = podPreview || (podFile ? podFile.name : 'no-image');
      const res = await api.submitPOD(podConsId.trim(), { receivedBy, receiverContact, remarks: podRemarks, podImage });
      setPodSuccess(res);
      await loadData();
      setPodConsId(''); setReceivedBy(''); setReceiverContact(''); setPodRemarks('');
      setPodFile(null); setPodPreview(null);
    } catch (err) { setPodError(err.message || 'POD submission failed.'); }
    finally { setPodLoading(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm(`Delete consignment ${id}?`)) return;
    setDeleteId(id);
    try {
      const store = api.getMockStore();
      store.consignments = store.consignments.filter(c => c.consignmentId !== id);
      setConsignments(prev => prev.filter(c => c.consignmentId !== id));
    } finally { setDeleteId(null); }
  };

  const fmtDate = v => v ? new Date(v).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';

  return (
    <div className="page-container animate-slideup">

      {/* Page Header */}
      <div className="page-header">
        <div>
          <h2 className="page-title"><Package size={22} color="var(--primary)" /> Consignments</h2>
          <p className="page-subtitle">Manage shipments, book new consignments, and record proof of delivery.</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className={`btn ${activeTab === 'list' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setActiveTab('list')}>
            All Consignments
          </button>
          <button className={`btn ${activeTab === 'book' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => { setActiveTab('book'); setBookStep(1); setBookSuccess(null); }}>
            <Plus size={15} /> Book New
          </button>
          <button className={`btn ${activeTab === 'pod' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setActiveTab('pod')}>
            <FileCheck size={15} /> Submit POD
          </button>
        </div>
      </div>

      {/* ─── LIST TAB ─── */}
      {activeTab === 'list' && (
        <div className="section-card">
          <div className="section-card-header">
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <Package size={15} color="var(--text-secondary)" />
              <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>All Consignments</span>
              <span style={{ background: '#f1f5f9', color: 'var(--text-secondary)', padding: '2px 8px', borderRadius: 999, fontSize: '0.75rem', fontWeight: 600 }}>
                {consignments.length}
              </span>
            </div>
          </div>
          <div className="table-wrapper">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Consignment ID</th>
                  <th>Origin Hub</th>
                  <th>Destination Hub</th>
                  <th>Status</th>
                  <th>Items</th>
                  <th>Total Weight</th>
                  <th>Created At</th>
                  <th style={{ textAlign: 'center' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {consignments.length === 0 ? (
                  <tr><td colSpan={8} style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>No consignments yet.</td></tr>
                ) : consignments.map(c => {
                  const totalWt = (c.items || []).reduce((s, i) => s + (parseFloat(i.weight) || 0), 0);
                  return (
                    <tr key={c.consignmentId}>
                      <td><span className="code-tag">{c.consignmentId}</span></td>
                      <td>{c.sourceLocation}</td>
                      <td>{c.destinationLocation}</td>
                      <td>
                        <span className={`badge ${STATUS_BADGE[c.status] || 'badge-info'}`}>
                          {(c.status || '').replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td style={{ textAlign: 'center' }}>{(c.items || []).length}</td>
                      <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8rem' }}>{totalWt.toFixed(1)} kg</td>
                      <td style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{fmtDate(c.createdAt)}</td>
                      <td>
                        <div style={{ display: 'flex', gap: 6, justifyContent: 'center' }}>
                          <button className="btn-icon edit" title="Edit" onClick={() => alert(`Edit ${c.consignmentId}`)}>
                            <Pencil size={14} />
                          </button>
                          <button
                            className="btn-icon delete" title="Delete"
                            disabled={deleteId === c.consignmentId}
                            onClick={() => handleDelete(c.consignmentId)}
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ─── BOOK TAB — 3-Step Wizard ─── */}
      {activeTab === 'book' && (
        <div className="grid-cols-3">
          <div className="section-card" style={{ gridColumn: 'span 2' }}>
            <div className="section-card-header">
              <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>Booking Wizard</span>
            </div>
            <div className="section-card-body">

              {/* Stepper indicator */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28, position: 'relative' }}>
                <div className="stepper-connector" />
                <div style={{
                  position: 'absolute', top: 18, left: '10%',
                  width: bookStep === 1 ? '0%' : bookStep === 2 ? '40%' : '80%',
                  height: 2, background: 'var(--primary)', transition: 'width 0.4s ease', zIndex: 0
                }} />
                {[{ s: 1, lbl: 'Route' }, { s: 2, lbl: 'Manifest' }, { s: 3, lbl: 'Confirm' }].map(node => (
                  <div key={node.s} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', zIndex: 1 }}>
                    <div style={{
                      width: 36, height: 36, borderRadius: '50%',
                      background: bookStep >= node.s ? 'var(--primary)' : '#fff',
                      border: `2px solid ${bookStep >= node.s ? 'var(--primary)' : 'var(--border-color)'}`,
                      color: bookStep >= node.s ? '#fff' : 'var(--text-muted)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontWeight: 700, fontSize: '0.9rem', transition: 'all 0.25s'
                    }}>{node.s}</div>
                    <span style={{ fontSize: '0.75rem', marginTop: 5, fontWeight: 600, color: bookStep >= node.s ? 'var(--primary)' : 'var(--text-muted)' }}>
                      {node.lbl}
                    </span>
                  </div>
                ))}
              </div>

              {/* Step 1 */}
              {bookStep === 1 && !bookSuccess && (
                <div className="animate-slideup">
                  <p style={{ fontWeight: 600, marginBottom: 16, color: 'var(--text-secondary)' }}>Select origin and destination hubs</p>
                  <div className="grid-cols-2">
                    <div className="form-group">
                      <label className="form-label">Origin Hub</label>
                      <select className="form-select" value={sourceHub} onChange={e => setSourceHub(e.target.value)}>
                        {locations.map(l => <option key={l.locationCode} value={l.locationCode}>{l.locationCode} — {l.city}</option>)}
                      </select>
                    </div>
                    <div className="form-group">
                      <label className="form-label">Destination Hub</label>
                      <select className="form-select" value={destHub} onChange={e => setDestHub(e.target.value)}>
                        {locations.map(l => <option key={l.locationCode} value={l.locationCode}>{l.locationCode} — {l.city}</option>)}
                      </select>
                    </div>
                  </div>
                  {bookError && <p style={{ color: 'var(--danger)', fontSize: '0.85rem', marginBottom: 10 }}>{bookError}</p>}
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                    <button className="btn btn-primary" onClick={nextStep}>Next <ArrowRight size={15} /></button>
                  </div>
                </div>
              )}

              {/* Step 2 */}
              {bookStep === 2 && !bookSuccess && (
                <div className="animate-slideup">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                    <p style={{ fontWeight: 600, color: 'var(--text-secondary)' }}>Add items to the manifest</p>
                    <button className="btn btn-secondary" style={{ padding: '5px 12px', fontSize: '0.8rem' }} onClick={addItem}>+ Add Item</button>
                  </div>

                  <div style={{ maxHeight: 260, overflowY: 'auto' }}>
                    <table className="data-table" style={{ fontSize: '0.8rem' }}>
                      <thead>
                        <tr>
                          <th>Barcode</th><th>Weight (kg)</th><th>Dimensions</th><th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {items.map((item, idx) => (
                          <tr key={idx}>
                            <td><input className="form-input code-tag" style={{ padding: '5px 8px' }} value={item.barcode} onChange={e => changeItem(idx, 'barcode', e.target.value)} /></td>
                            <td><input type="number" step="0.1" className="form-input" style={{ padding: '5px 8px' }} value={item.weight} onChange={e => changeItem(idx, 'weight', e.target.value)} /></td>
                            <td><input className="form-input" style={{ padding: '5px 8px' }} value={item.dimensions} onChange={e => changeItem(idx, 'dimensions', e.target.value)} /></td>
                            <td>
                              <button className="btn-icon delete" disabled={items.length === 1} onClick={() => removeItem(idx)}>
                                <Trash2 size={13} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 14, padding: '10px 14px', background: '#f8fafc', borderRadius: 8, border: '1px dashed var(--primary)' }}>
                    <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{items.length} items</span>
                    <span style={{ fontWeight: 700, color: 'var(--primary)' }}>Total: {totalWeight.toFixed(1)} kg</span>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 16 }}>
                    <button className="btn btn-secondary" onClick={prevStep}><ArrowLeft size={15} /> Back</button>
                    <button className="btn btn-primary" onClick={nextStep}>Review <ArrowRight size={15} /></button>
                  </div>
                </div>
              )}

              {/* Step 3 */}
              {bookStep === 3 && !bookSuccess && (
                <div className="animate-slideup">
                  <p style={{ fontWeight: 600, marginBottom: 16, color: 'var(--text-secondary)' }}>Review and confirm booking</p>
                  <div style={{ background: '#f8fafc', borderRadius: 8, padding: '14px 18px', fontSize: '0.875rem', display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20, border: '1px solid var(--border-color)' }}>
                    <p><strong>Origin:</strong> {sourceHub}</p>
                    <p><strong>Destination:</strong> {destHub}</p>
                    <p><strong>Items:</strong> {items.length}</p>
                    <p><strong>Total Weight:</strong> {totalWeight.toFixed(1)} kg</p>
                  </div>
                  {bookError && <p style={{ color: 'var(--danger)', fontSize: '0.85rem', marginBottom: 10 }}>{bookError}</p>}
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <button className="btn btn-secondary" onClick={prevStep}><ArrowLeft size={15} /> Edit</button>
                    <button className="btn btn-primary" onClick={handleBook} disabled={bookLoading}>
                      <CheckCircle2 size={15} /> {bookLoading ? 'Booking…' : 'Confirm & Book'}
                    </button>
                  </div>
                </div>
              )}

              {/* Success */}
              {bookSuccess && (
                <div className="animate-slideup" style={{ textAlign: 'center', padding: '24px 0' }}>
                  <CheckCircle2 size={48} color="var(--success)" style={{ marginBottom: 10 }} />
                  <h4 style={{ color: 'var(--success)', marginBottom: 6 }}>Consignment Booked!</h4>
                  <p className="code-tag" style={{ display: 'inline-block', marginBottom: 16 }}>{bookSuccess.consignmentId}</p>
                  <br />
                  <button className="btn btn-primary" onClick={() => { setBookSuccess(null); setBookStep(1); }}>Book Another</button>
                </div>
              )}
            </div>
          </div>

          {/* Side info */}
          <div className="section-card" style={{ padding: 20 }}>
            <h4 style={{ fontWeight: 700, marginBottom: 10, fontSize: '0.95rem' }}>Booking Guide</h4>
            <ol style={{ paddingLeft: 18, display: 'flex', flexDirection: 'column', gap: 8, fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              <li>Select origin and destination hubs.</li>
              <li>Add item barcodes, weights, and dimensions.</li>
              <li>Confirm booking — system assigns a Consignment ID.</li>
              <li>Print barcode stickers and attach to packages.</li>
              <li>Scan items at source terminal to begin transit.</li>
            </ol>
          </div>
        </div>
      )}

      {/* ─── POD TAB ─── */}
      {activeTab === 'pod' && (
        <div className="grid-cols-3">
          <div className="section-card" style={{ gridColumn: 'span 2' }}>
            <div className="section-card-header">
              <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>Submit Proof of Delivery</span>
            </div>
            <div className="section-card-body">
              <form onSubmit={handlePod}>
                <div className="form-group">
                  <label className="form-label">Consignment Tracking ID</label>
                  <input className="form-input code-tag" value={podConsId} onChange={e => setPodConsId(e.target.value)} placeholder="e.g. CON-982103" required />
                </div>
                <div className="grid-cols-2">
                  <div className="form-group">
                    <label className="form-label">Received By</label>
                    <input className="form-input" value={receivedBy} onChange={e => setReceivedBy(e.target.value)} placeholder="Recipient full name" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Contact Number</label>
                    <input className="form-input" value={receiverContact} onChange={e => setReceiverContact(e.target.value)} placeholder="+1 212 555 0100" required />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Delivery Remarks</label>
                  <textarea className="form-textarea" rows={3} value={podRemarks} onChange={e => setPodRemarks(e.target.value)} placeholder="e.g. Delivered to front desk, package intact" />
                </div>

                {/* Photo / Camera Upload */}
                <div className="form-group">
                  <label className="form-label">Signature / Delivery Photo</label>
                  <div style={{
                    border: '2px dashed var(--border-color)', borderRadius: 10, padding: 20,
                    textAlign: 'center', background: '#fafbfc', cursor: 'pointer', transition: 'border-color 0.2s'
                  }}
                    onDragOver={e => e.preventDefault()}
                    onDrop={e => { e.preventDefault(); const f = e.dataTransfer.files?.[0]; if (f) { setPodFile(f); const r = new FileReader(); r.onloadend = () => setPodPreview(r.result); r.readAsDataURL(f); } }}
                  >
                    {podPreview ? (
                      <div style={{ position: 'relative', display: 'inline-block' }}>
                        <img src={podPreview} alt="POD preview" style={{ maxHeight: 160, maxWidth: '100%', borderRadius: 8, boxShadow: 'var(--shadow-sm)' }} />
                        <button type="button" onClick={() => { setPodFile(null); setPodPreview(null); }}
                          style={{ position: 'absolute', top: -8, right: -8, background: 'var(--danger)', color: '#fff', border: 'none', borderRadius: '50%', width: 22, height: 22, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <X size={12} />
                        </button>
                      </div>
                    ) : (
                      <label htmlFor="pod-file-input" style={{ cursor: 'pointer', display: 'block' }}>
                        <div style={{ fontSize: '2rem', marginBottom: 6 }}>📷</div>
                        <p style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: 4 }}>Click to upload or drag & drop</p>
                        <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Or use camera on mobile — PNG, JPG, PDF</p>
                        <div style={{ display: 'flex', gap: 10, justifyContent: 'center', marginTop: 12 }}>
                          <label htmlFor="pod-file-input" className="btn btn-secondary" style={{ cursor: 'pointer', fontSize: '0.8rem', padding: '7px 14px' }}>
                            📁 Choose File
                          </label>
                          <label htmlFor="pod-camera-input" className="btn btn-secondary" style={{ cursor: 'pointer', fontSize: '0.8rem', padding: '7px 14px' }}>
                            📷 Use Camera
                          </label>
                        </div>
                      </label>
                    )}
                    <input id="pod-file-input" type="file" accept="image/*,application/pdf" onChange={handlePodFile} style={{ display: 'none' }} />
                    <input id="pod-camera-input" type="file" accept="image/*" capture="environment" onChange={handlePodFile} style={{ display: 'none' }} />
                  </div>
                </div>

                {podError && <div style={{ padding: '10px 14px', background: 'var(--danger-bg)', border: '1px solid #fca5a5', borderRadius: 8, color: 'var(--danger)', fontSize: '0.85rem', marginBottom: 12 }}>{podError}</div>}

                {podSuccess ? (
                  <div style={{ textAlign: 'center', padding: '16px 0' }}>
                    <CheckCircle2 size={40} color="var(--success)" style={{ marginBottom: 8 }} />
                    <p style={{ fontWeight: 700, color: 'var(--success)' }}>POD recorded for {podSuccess.consignmentId}!</p>
                  </div>
                ) : (
                  <button type="submit" className="btn btn-success" style={{ width: '100%', padding: 12 }} disabled={podLoading}>
                    <FileCheck size={16} /> {podLoading ? 'Submitting…' : 'Submit Proof of Delivery'}
                  </button>
                )}
              </form>
            </div>
          </div>

          <div className="section-card" style={{ padding: 20 }}>
            <h4 style={{ fontWeight: 700, marginBottom: 10, fontSize: '0.95rem' }}>POD Requirements</h4>
            <ul style={{ paddingLeft: 18, display: 'flex', flexDirection: 'column', gap: 8, fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              <li>Enter the exact Consignment Tracking ID.</li>
              <li>Capture recipient name and contact number.</li>
              <li>Upload a photo of signed delivery receipt.</li>
              <li>On mobile, use the camera option to capture in-person.</li>
              <li>System marks consignment as DELIVERED on submission.</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
