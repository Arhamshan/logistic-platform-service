// API Service Client for ARQON Logistic Platform

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/v1';

// Dynamic In-Memory Store for Mock Fallback Testing
const mockStore = {
  locations: [
    {
      id: 1, locationCode: 'LOC001', name: 'New York Central Hub',
      type: 'HUB', city: 'New York', country: 'United States',
      latitude: 40.7128, longitude: -74.0060,
      createdDate: '2025-01-10T09:00:00Z', createdBy: 'admin',
      updatedDate: '2026-03-15T11:20:00Z', updatedBy: 'admin'
    },
    {
      id: 2, locationCode: 'LOC002', name: 'London Sorting Centre',
      type: 'SORTING_CENTER', city: 'London', country: 'United Kingdom',
      latitude: 51.5074, longitude: -0.1278,
      createdDate: '2025-02-05T08:30:00Z', createdBy: 'admin',
      updatedDate: '2026-01-20T14:45:00Z', updatedBy: 'ops_user1'
    },
    {
      id: 3, locationCode: 'LOC003', name: 'Tokyo Distribution Center',
      type: 'DISTRIBUTION_CENTER', city: 'Tokyo', country: 'Japan',
      latitude: 35.6762, longitude: 139.6503,
      createdDate: '2025-03-12T07:00:00Z', createdBy: 'admin',
      updatedDate: '2026-04-02T09:10:00Z', updatedBy: 'admin'
    },
    {
      id: 4, locationCode: 'LOC004', name: 'Frankfurt Gateway Terminal',
      type: 'GATEWAY', city: 'Frankfurt', country: 'Germany',
      latitude: 50.1109, longitude: 8.6821,
      createdDate: '2025-04-20T10:15:00Z', createdBy: 'ops_user2',
      updatedDate: '2026-05-11T16:30:00Z', updatedBy: 'ops_user2'
    }
  ],
  consignments: [
    {
      consignmentId: 'CON-982103',
      sourceLocation: 'LOC001',
      destinationLocation: 'LOC003',
      status: 'IN_TRANSIT',
      createdAt: '2026-06-01T08:00:00Z',
      items: [
        { id: 101, barcode: 'BAR-00101', weight: 4.5, dimensions: '30x20x15 cm', status: 'IN_TRANSIT' },
        { id: 102, barcode: 'BAR-00102', weight: 1.2, dimensions: '15x10x5 cm', status: 'IN_TRANSIT' }
      ]
    },
    {
      consignmentId: 'CON-452109',
      sourceLocation: 'LOC002',
      destinationLocation: 'LOC004',
      status: 'DELIVERED',
      createdAt: '2026-05-30T10:00:00Z',
      items: [
        { id: 201, barcode: 'BAR-00201', weight: 12.0, dimensions: '50x50x40 cm', status: 'DELIVERED' }
      ],
      pod: {
        receivedBy: 'Emma Watson',
        receiverContact: '+49 172 888999',
        timestamp: '2026-05-31T15:30:00Z',
        remarks: 'Package delivered in good condition',
        podImage: 'https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&q=80&w=400'
      }
    }
  ],
  events: [
    { id: 501, consignmentId: 'CON-982103', itemBarcode: 'BAR-00101', locationCode: 'LOC001', eventType: 'BOOKED', remarks: 'Consignment booked successfully', timestamp: '2026-06-01T08:00:00Z', operatorId: 'OP-04' },
    { id: 502, consignmentId: 'CON-982103', itemBarcode: 'BAR-00102', locationCode: 'LOC001', eventType: 'BOOKED', remarks: 'Consignment booked successfully', timestamp: '2026-06-01T08:00:00Z', operatorId: 'OP-04' },
    { id: 503, consignmentId: 'CON-982103', itemBarcode: 'BAR-00101', locationCode: 'LOC001', eventType: 'DISPATCHED', remarks: 'Dispatched from New York Hub', timestamp: '2026-06-01T10:30:00Z', operatorId: 'OP-04' },
    { id: 504, consignmentId: 'CON-452109', itemBarcode: 'BAR-00201', locationCode: 'LOC002', eventType: 'BOOKED', remarks: 'Shipment initiated', timestamp: '2026-05-30T10:00:00Z', operatorId: 'OP-01' },
    { id: 505, consignmentId: 'CON-452109', itemBarcode: 'BAR-00201', locationCode: 'LOC004', eventType: 'DELIVERED', remarks: 'Delivered to recipient', timestamp: '2026-05-31T15:30:00Z', operatorId: 'OP-02' }
  ]
};

// Helper: Get Auth headers
const getHeaders = (contentType = 'application/json') => {
  const token = localStorage.getItem('arqon_token');
  const headers = {};
  if (contentType) {
    headers['Content-Type'] = contentType;
  }
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
};

// API Fetch Core Wrapper with Automatic Fallback
async function apiCall(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        ...getHeaders(options.body instanceof FormData ? null : 'application/json'),
        ...options.headers
      }
    });

    if (!response.ok) {
      const errBody = await response.json().catch(() => ({}));
      throw new Error(errBody.message || `API Error: Status ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.warn(`[ARQON API Fallback] Request to ${url} failed. Using mock environment.`, error);
    return handleMockRequest(endpoint, options);
  }
}

// Mock Request Handler simulating backend behaviors
function handleMockRequest(endpoint, options) {
  const method = options.method || 'GET';
  const data = options.body ? JSON.parse(options.body) : null;

  // 1. POST /v1/auth/login
  if (endpoint.startsWith('/auth/login') && method === 'POST') {
    const { username, password } = data;
    if (username && password) {
      const role = username.toLowerCase().includes('admin') ? 'ADMIN' : 'OPERATIONAL_USER';
      return {
        token: `mock-jwt-${Math.random().toString(36).substring(2)}`,
        username,
        role
      };
    }
    throw new Error('Invalid credentials');
  }

  // 2. POST /v1/user
  if (endpoint.startsWith('/user') && method === 'POST') {
    return { success: true, message: 'User registered in mock store', user: data };
  }

  // 3. GET /v1/location
  if (endpoint === '/location' && method === 'GET') {
    return mockStore.locations;
  }

  // 4. POST /v1/location
  if (endpoint === '/location' && method === 'POST') {
    const nextId = mockStore.locations.reduce((m, l) => Math.max(m, l.id || 0), 0) + 1;
    const code = data.locationCode || `LOC${String(nextId).padStart(3, '0')}`;
    const now = new Date().toISOString();
    const user = JSON.parse(localStorage.getItem('arqon_user') || '{}')?.username || 'system';
    const newLoc = {
      id: nextId, ...data, locationCode: code,
      createdDate: now, createdBy: user,
      updatedDate: now, updatedBy: user
    };
    mockStore.locations.push(newLoc);
    return newLoc;
  }

  // 5. PUT /v1/location
  if (endpoint === '/location' && method === 'PUT') {
    const index = mockStore.locations.findIndex(l => l.locationCode === data.locationCode);
    if (index !== -1) {
      const now = new Date().toISOString();
      const user = JSON.parse(localStorage.getItem('arqon_user') || '{}')?.username || 'system';
      mockStore.locations[index] = {
        ...mockStore.locations[index], ...data,
        updatedDate: now, updatedBy: user
      };
      return mockStore.locations[index];
    }
    throw new Error('Location not found');
  }

  // 6. GET /v1/location/{locationCode}
  if (endpoint.startsWith('/location/') && method === 'GET') {
    const code = endpoint.split('/')[2];
    const loc = mockStore.locations.find(l => l.locationCode === code);
    if (loc) return loc;
    throw new Error('Location not found');
  }

  // 7. POST /v1/consignment
  if (endpoint === '/consignment' && method === 'POST') {
    const newConsignment = {
      consignmentId: data.consignmentId || `CON-${Math.floor(100000 + Math.random() * 900000)}`,
      sourceLocation: data.sourceLocation,
      destinationLocation: data.destinationLocation,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
      items: data.items.map((it, idx) => ({
        id: Math.floor(1000 + Math.random() * 9000),
        barcode: it.barcode || `BAR-${Math.floor(10000 + Math.random() * 90000)}`,
        weight: it.weight,
        dimensions: it.dimensions || 'N/A',
        status: 'PENDING'
      }))
    };

    mockStore.consignments.push(newConsignment);

    // Create booking events for each item
    newConsignment.items.forEach(item => {
      mockStore.events.push({
        id: Math.floor(1000 + Math.random() * 9000),
        consignmentId: newConsignment.consignmentId,
        itemBarcode: item.barcode,
        locationCode: newConsignment.sourceLocation,
        eventType: 'BOOKED',
        remarks: 'Item booked in system',
        timestamp: new Date().toISOString(),
        operatorId: 'SYSTEM'
      });
    });

    return newConsignment;
  }

  // 8. GET /v1/consignment/track/{consignmentId}
  if (endpoint.startsWith('/consignment/track/') && method === 'GET') {
    const cId = endpoint.split('/')[3];
    const consignment = mockStore.consignments.find(c => c.consignmentId === cId);
    if (!consignment) throw new Error(`Consignment ${cId} not found`);
    const rawEvents = mockStore.events
      .filter(e => e.consignmentId === cId)
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    // Build unique timeline by eventType
    const seen = new Set();
    const events = [];
    for (const ev of rawEvents) {
      const key = ev.eventType;
      if (!seen.has(key)) {
        seen.add(key);
        events.push({
          status: ev.eventType,
          location: ev.locationCode,
          timestamp: ev.timestamp,
          description: ev.remarks
        });
      }
    }
    return {
      ...consignment,
      events,
      trackingEvents: events
    };
  }

  // 9. GET /v1/consignment/summary
  if (endpoint === '/consignment/summary' && method === 'GET') {
    const summary = {
      total: mockStore.consignments.length,
      pending: mockStore.consignments.filter(c => c.status === 'PENDING').length,
      inTransit: mockStore.consignments.filter(c => c.status === 'IN_TRANSIT').length,
      delivered: mockStore.consignments.filter(c => c.status === 'DELIVERED').length
    };
    return summary;
  }

  // 10. POST /v1/consignment/{consignmentId}/pod
  if (endpoint.includes('/pod') && method === 'POST') {
    const parts = endpoint.split('/');
    const cId = parts[2];
    const index = mockStore.consignments.findIndex(c => c.consignmentId === cId);
    if (index !== -1) {
      mockStore.consignments[index].status = 'DELIVERED';
      mockStore.consignments[index].pod = {
        receivedBy: data.receivedBy || 'Recipient',
        receiverContact: data.receiverContact || 'N/A',
        timestamp: new Date().toISOString(),
        remarks: data.remarks || 'Delivered successfully',
        podImage: data.podImage || 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=400'
      };

      // Add a delivered event
      mockStore.events.push({
        id: Math.floor(1000 + Math.random() * 9000),
        consignmentId: cId,
        itemBarcode: mockStore.consignments[index].items[0]?.barcode || 'ALL',
        locationCode: mockStore.consignments[index].destinationLocation,
        eventType: 'DELIVERED',
        remarks: `Delivered to ${data.receivedBy}`,
        timestamp: new Date().toISOString(),
        operatorId: 'SYSTEM'
      });

      return mockStore.consignments[index];
    }
    throw new Error('Consignment not found');
  }

  // 11. POST /v1/event
  if (endpoint === '/event' && method === 'POST') {
    const newEvent = {
      id: Math.floor(1000 + Math.random() * 9000),
      ...data,
      timestamp: new Date().toISOString()
    };
    mockStore.events.push(newEvent);

    // Update individual item status if matched
    mockStore.consignments.forEach(c => {
      if (c.consignmentId === data.consignmentId) {
        c.items.forEach(item => {
          if (item.barcode === data.itemBarcode) {
            item.status = data.eventType;
          }
        });
      }
    });

    return newEvent;
  }

  // 12. POST /v1/items/scan
  if (endpoint === '/items/scan' && method === 'POST') {
    const { barcode, locationCode, status, employeeId, remarks } = data;
    
    // Find the item and parent consignment in mock store
    let matchedItem = null;
    let parentConsignment = null;
    
    for (const c of mockStore.consignments) {
      const it = c.items.find(item => item.barcode === barcode);
      if (it) {
        matchedItem = it;
        parentConsignment = c;
        break;
      }
    }

    if (!matchedItem) {
      throw new Error(`Item with barcode ${barcode} not found`);
    }

    // Update item status
    matchedItem.status = status || 'SCANNED';

    // Add scan event
    const newEvent = {
      id: Math.floor(1000 + Math.random() * 9000),
      consignmentId: parentConsignment.consignmentId,
      itemBarcode: barcode,
      locationCode: locationCode,
      eventType: status || 'SCANNED',
      remarks: remarks || `Barcode scanned at hub ${locationCode}`,
      timestamp: new Date().toISOString(),
      operatorId: employeeId || 'OP-SCANNER'
    };
    mockStore.events.push(newEvent);

    // Determine consignment-wide status
    const allStatuses = parentConsignment.items.map(it => it.status);
    if (allStatuses.every(s => s === 'DELIVERED')) {
      parentConsignment.status = 'DELIVERED';
    } else if (allStatuses.some(s => ['IN_TRANSIT', 'SORTING', 'SCANNED'].includes(s))) {
      parentConsignment.status = 'IN_TRANSIT';
    }

    return {
      success: true,
      message: 'Barcode scan recorded',
      scannedItem: matchedItem,
      consignmentStatus: parentConsignment.status,
      event: newEvent
    };
  }

  // 13. PATCH /v1/items/{status}/{id}
  if (endpoint.startsWith('/items/') && method === 'PATCH') {
    const parts = endpoint.split('/');
    const status = parts[2];
    const id = parseInt(parts[3]);

    let matchedItem = null;
    let parentConsignment = null;
    
    for (const c of mockStore.consignments) {
      const it = c.items.find(item => item.id === id);
      if (it) {
        matchedItem = it;
        parentConsignment = c;
        break;
      }
    }

    if (!matchedItem) {
      throw new Error(`Item with ID ${id} not found`);
    }

    matchedItem.status = status;

    // Create tracking event
    const newEvent = {
      id: Math.floor(1000 + Math.random() * 9000),
      consignmentId: parentConsignment.consignmentId,
      itemBarcode: matchedItem.barcode,
      locationCode: parentConsignment.sourceLocation,
      eventType: status,
      remarks: `Status patched directly to ${status}`,
      timestamp: new Date().toISOString(),
      operatorId: 'SYSTEM'
    };
    mockStore.events.push(newEvent);

    return matchedItem;
  }

  return { success: true };
}

// Exportable API Client
export const api = {
  // Auth & Session
  login: (username, password, requestId = 'REQ-001') => 
    apiCall('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
      headers: { 'X-Request-ID': requestId }
    }),

  register: (username, password, role) =>
    apiCall('/user', {
      method: 'POST',
      body: JSON.stringify({ username, password, role })
    }),

  // Hub / Location Management
  getLocations: () => apiCall('/location'),
  
  getLocation: (code) => apiCall(`/location/${code}`),
  
  createLocation: (locationData) =>
    apiCall('/location', {
      method: 'POST',
      body: JSON.stringify(locationData)
    }),
    
  updateLocation: (locationData) =>
    apiCall('/location', {
      method: 'PUT',
      body: JSON.stringify(locationData)
    }),

  // Shipment / Consignment Management
  bookConsignment: (consignmentData) =>
    apiCall('/consignment', {
      method: 'POST',
      body: JSON.stringify(consignmentData)
    }),

  getConsignmentTrack: (consignmentId) =>
    apiCall(`/consignment/track/${consignmentId}`),

  getConsignmentSummary: () =>
    apiCall('/consignment/summary'),

  submitPOD: (consignmentId, podData) =>
    apiCall(`/consignment/${consignmentId}/pod`, {
      method: 'POST',
      body: JSON.stringify(podData)
    }),

  // Operational Scan & Events
  createEvent: (eventData) =>
    apiCall('/event', {
      method: 'POST',
      body: JSON.stringify(eventData)
    }),

  scanBarcode: (scanData) =>
    apiCall('/items/scan', {
      method: 'POST',
      body: JSON.stringify(scanData)
    }),

  // Convenience wrapper used by Scanner page
  scanItem: (barcode, { location, status } = {}) =>
    apiCall('/items/scan', {
      method: 'POST',
      body: JSON.stringify({
        barcode,
        locationCode: location,
        status: status || 'IN_TRANSIT',
        employeeId: JSON.parse(localStorage.getItem('arqon_user') || '{}')?.username || 'OP-SCANNER',
        remarks: `Scanned at ${location}`
      })
    }),

  patchItemStatus: (id, status) =>
    apiCall(`/items/${status}/${id}`, {
      method: 'PATCH'
    }),

  // Helper mock lists for select filters
  getMockStore: () => mockStore
};
