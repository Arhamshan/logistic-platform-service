import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Scan, Check, AlertCircle, ShieldAlert, Sparkles, ShieldCheck } from 'lucide-react';

export default function ScanSimulator({ onScanSuccess }) {
  const { user } = useAuth();
  const [locations, setLocations] = useState([]);
  const [barcode, setBarcode] = useState('');
  const [selectedHub, setSelectedHub] = useState('');
  const [status, setStatus] = useState('SORTING');
  const [remarks, setRemarks] = useState('');
  const [employeeId, setEmployeeId] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [suggestedBarcodes, setSuggestedBarcodes] = useState([]);
  
  // Immersive UI effects states
  const [flashState, setFlashState] = useState(null); // 'success' | 'fail' | null
  const inputRef = useRef(null);

  // Web Audio Synth engine to play premium browser double beeps/buzzes
  const playSound = (type) => {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();

      if (type === 'success') {
        // High pitched elegant double-beep
        const now = ctx.currentTime;
        // First beep
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(880, now); // A5 note
        gain1.gain.setValueAtTime(0.15, now);
        gain1.gain.exponentialRampToValueAtTime(0.01, now + 0.08);
        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        osc1.start(now);
        osc1.stop(now + 0.08);

        // Second beep
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(1174.66, now + 0.09); // D6 note
        gain2.gain.setValueAtTime(0.15, now + 0.09);
        gain2.gain.exponentialRampToValueAtTime(0.01, now + 0.17);
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.start(now + 0.09);
        osc2.stop(now + 0.17);
      } else {
        // Low pitched error double-buzz
        const now = ctx.currentTime;
        
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'sawtooth';
        osc1.frequency.setValueAtTime(180, now);
        gain1.gain.setValueAtTime(0.2, now);
        gain1.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        osc1.start(now);
        osc1.stop(now + 0.15);

        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.type = 'sawtooth';
        osc2.frequency.setValueAtTime(140, now + 0.17);
        gain2.gain.setValueAtTime(0.2, now + 0.17);
        gain2.gain.exponentialRampToValueAtTime(0.01, now + 0.32);
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.start(now + 0.17);
        osc2.stop(now + 0.32);
      }
    } catch (e) {
      console.warn('Web Audio synthesis blocked by browser security/permissions', e);
    }
  };

  useEffect(() => {
    async function loadData() {
      try {
        const locs = await api.getLocations();
        setLocations(locs);
        if (locs.length > 0) {
          setSelectedHub(locs[0].locationCode);
        }

        const store = api.getMockStore();
        const barcodes = [];
        store.consignments.forEach(c => {
          c.items.forEach(it => {
            if (it.status !== 'DELIVERED') {
              barcodes.push(it.barcode);
            }
          });
        });
        setSuggestedBarcodes(barcodes);
        if (barcodes.length > 0) {
          setBarcode(barcodes[0]);
        }
      } catch (err) {
        console.error(err);
      }
    }
    loadData();

    if (user) {
      setEmployeeId(`EMP-${user.username.toUpperCase()}-09`);
    }

    // Connect global shortcut event for Ctrl + S Focus-Lock
    const handleFocusLock = () => {
      if (inputRef.current) {
        inputRef.current.focus();
        inputRef.current.select();
      }
    };

    window.addEventListener('focus-scanner-field', handleFocusLock);
    return () => window.removeEventListener('focus-scanner-field', handleFocusLock);
  }, [user]);

  const handleSubmit = async (e) => {
    if (e) e.preventDefault();
    if (!barcode || !selectedHub) {
      setError('Please provide a barcode and select a scanning hub.');
      playSound('error');
      setFlashState('fail');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const payload = {
        barcode,
        locationCode: selectedHub,
        status,
        employeeId,
        remarks: remarks || `Scanned at ${selectedHub} terminal`
      };

      const res = await api.scanBarcode(payload);
      setResult(res);
      setRemarks('');
      
      // Immersive success effects!
      playSound('success');
      setFlashState('success');
      setTimeout(() => setFlashState(null), 500);

      // Notify parent to refresh stats
      if (onScanSuccess) {
        onScanSuccess();
      }

      // Re-fetch suggested list
      const store = api.getMockStore();
      const barcodes = [];
      store.consignments.forEach(c => {
        c.items.forEach(it => {
          if (it.status !== 'DELIVERED') {
            barcodes.push(it.barcode);
          }
        });
      });
      setSuggestedBarcodes(barcodes);
    } catch (err) {
      setError(err.message || 'Scanning simulation failed.');
      // Immersive fail effects!
      playSound('error');
      setFlashState('fail');
      setTimeout(() => setFlashState(null), 500);
    } finally {
      setLoading(false);
    }
  };

  // Direct Quick Status Modifier PATCH triggers (optimizations for damages/misplacements)
  const handleQuickPatch = async (modifierStatus) => {
    if (!barcode) {
      setError('Please select/input an item barcode first.');
      playSound('error');
      return;
    }
    
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      // Look up target item ID in mockStore/backend
      const store = api.getMockStore();
      let itemId = null;
      for (const c of store.consignments) {
        const found = c.items.find(it => it.barcode === barcode);
        if (found) {
          itemId = found.id;
          break;
        }
      }

      if (!itemId) {
        throw new Error(`Item ${barcode} has no technical database identifier.`);
      }

      const res = await api.patchItemStatus(itemId, modifierStatus);
      
      playSound('success');
      setFlashState('success');
      setTimeout(() => setFlashState(null), 500);

      setResult({
        scannedItem: { barcode, status: modifierStatus },
        consignmentStatus: 'EXCEPTION',
        message: `Quick patched status directly to ${modifierStatus}`
      });

      if (onScanSuccess) {
        onScanSuccess();
      }
    } catch (err) {
      setError(err.message || 'Failed to patch item status.');
      playSound('error');
      setFlashState('fail');
      setTimeout(() => setFlashState(null), 500);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`glass-panel ${flashState === 'success' ? 'flash-success' : flashState === 'fail' ? 'flash-fail' : ''}`} style={{
      padding: '24px',
      position: 'relative',
      overflow: 'hidden',
      transition: 'background-color 0.2s ease'
    }}>
      {/* Laser scan line backdrop */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: '2px',
        background: 'rgba(139, 92, 246, 0.4)',
        boxShadow: '0 0 10px rgba(139, 92, 246, 0.8)',
        animation: 'scanLine 3.5s infinite ease-in-out',
        pointerEvents: 'none'
      }} />

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes scanLine {
          0% { top: 0%; }
          50% { top: 100%; }
          100% { top: 0%; }
        }
        .barcode-stripes span {
          display: inline-block;
          height: 40px;
          background: var(--text-primary);
        }
      `}} />

      <h3 style={{ fontSize: '1.25rem', marginBottom: '6px', color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <Scan style={{ color: 'var(--primary)' }} size={20} className="pulse-primary" />
        High-Speed Terminal Scanner
      </h3>
      <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '16px' }}>
        Optimized for USB scan guns or keyboard-focused workflows. Press <kbd style={{ padding: '2px 4px', background: 'rgba(255,255,255,0.06)', borderRadius: '4px', fontStyle: 'normal', fontSize: '0.7rem' }}>Ctrl+S</kbd> to lock scanner focus.
      </p>

      {/* Suggested barcode helper chips */}
      {suggestedBarcodes.length > 0 && (
        <div style={{ marginBottom: '16px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>
            Available Barcodes in System:
          </span>
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            {suggestedBarcodes.slice(0, 4).map(bar => (
              <button
                key={bar}
                type="button"
                onClick={() => setBarcode(bar)}
                style={{
                  background: barcode === bar ? 'var(--primary-glow)' : 'rgba(255,255,255,0.02)',
                  border: `1px solid ${barcode === bar ? 'var(--primary)' : 'var(--border-color)'}`,
                  color: barcode === bar ? '#fff' : 'var(--text-secondary)',
                  borderRadius: '6px',
                  padding: '3px 8px',
                  fontSize: '0.7rem',
                  cursor: 'pointer',
                  fontFamily: 'var(--font-mono)',
                  transition: 'var(--transition-fast)'
                }}
              >
                {bar}
              </button>
            ))}
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="grid-cols-2">
          <div className="form-group">
            <label className="form-label">Scan Barcode ID</label>
            <input
              ref={inputRef}
              type="text"
              className="form-input code-tag"
              value={barcode}
              onChange={(e) => setBarcode(e.target.value)}
              placeholder="Laser scan input field"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Sorting Station Hub</label>
            <select
              className="form-select"
              value={selectedHub}
              onChange={(e) => setSelectedHub(e.target.value)}
              required
            >
              {locations.map(loc => (
                <option key={loc.locationCode} value={loc.locationCode}>
                  {loc.locationCode} - {loc.city} ({loc.type})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid-cols-2">
          <div className="form-group">
            <label className="form-label">Scan Status Flag</label>
            <select
              className="form-select"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="RECEIVED">RECEIVED (Inbound Scan)</option>
              <option value="SORTING">SORTING (Processing)</option>
              <option value="DISPATCHED">DISPATCHED (Outbound Scan)</option>
              <option value="DELIVERED">DELIVERED (Final Arrival)</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Operator Badge ID</label>
            <input
              type="text"
              className="form-input"
              value={employeeId}
              onChange={(e) => setEmployeeId(e.target.value)}
              placeholder="OP-SCANNER"
            />
          </div>
        </div>

        <div className="form-group" style={{ marginBottom: '20px' }}>
          <label className="form-label">Audit Remarks</label>
          <input
            type="text"
            className="form-input"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            placeholder="Remarks e.g. Belt sorting conveyor 2"
          />
        </div>

        <button
          type="submit"
          className="btn btn-primary"
          style={{ width: '100%', marginBottom: '16px' }}
          disabled={loading}
        >
          <Scan size={16} />
          {loading ? 'Recording Laser Scan...' : 'Trigger Barcode Scan'}
        </button>

        {/* Quick Quick Status Modifier buttons panel */}
        <div style={{ marginBottom: '20px' }}>
          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', display: 'block', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Quick Exception status overrides:
          </span>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
            <button
              type="button"
              className="btn btn-secondary"
              style={{ padding: '6px', fontSize: '0.75rem', borderColor: 'rgba(245, 158, 11, 0.3)', color: 'var(--warning)' }}
              onClick={() => handleQuickPatch('MISPLACED')}
              disabled={loading}
            >
              Misplaced
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              style={{ padding: '6px', fontSize: '0.75rem', borderColor: 'rgba(239, 68, 68, 0.3)', color: 'var(--danger)' }}
              onClick={() => handleQuickPatch('DAMAGED')}
              disabled={loading}
            >
              Damaged
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              style={{ padding: '6px', fontSize: '0.75rem', borderColor: 'rgba(255, 255, 255, 0.1)', color: 'var(--text-primary)' }}
              onClick={() => handleQuickPatch('REJECTED')}
              disabled={loading}
            >
              Rejected
            </button>
          </div>
        </div>
      </form>

      {/* Results details panel */}
      {result && (
        <div style={{
          padding: '12px 16px',
          background: 'var(--success-glow)',
          border: '1px solid rgba(142, 72, 52, 0.25)',
          borderRadius: '8px',
          display: 'flex',
          gap: '12px',
          alignItems: 'flex-start'
        }} className="animate-slideup">
          <ShieldCheck size={18} style={{ color: 'var(--success)', marginTop: '2px' }} />
          <div>
            <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--success)' }}>
              Scan Successful
            </h4>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
              Item <span className="code-tag">{result.scannedItem?.barcode}</span> marked <span style={{ fontWeight: 700, color: 'var(--primary)' }}>{result.scannedItem?.status}</span>.
              Consignment state: <span style={{ fontWeight: 700 }}>{result.consignmentStatus}</span>.
            </p>
          </div>
        </div>
      )}

      {error && (
        <div style={{
          padding: '12px 16px',
          background: 'var(--danger-glow)',
          border: '1px solid rgba(239, 68, 68, 0.25)',
          borderRadius: '8px',
          display: 'flex',
          gap: '12px',
          alignItems: 'flex-start'
        }} className="animate-slideup">
          <ShieldAlert size={18} style={{ color: 'var(--danger)', marginTop: '2px' }} />
          <div>
            <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--danger)' }}>
              Validation Exception
            </h4>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
              {error}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
