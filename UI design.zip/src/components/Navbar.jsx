import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Package, MapPin, BarChart3, LogOut, Shield, User, Scan, Search, Truck, FileText } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab }) {
  const { user, logout } = useAuth();
  const isDriver = user?.role === 'DRIVER';

  const navItems = isDriver ? [
    { id: 'dashboard',    label: 'Driver Portal', icon: Truck    },
    { id: 'scanner',     label: 'Scanner',       icon: Scan     },
  ] : [
    { id: 'dashboard',    label: 'Dashboard',    icon: BarChart3 },
    { id: 'consignments', label: 'Consignments',  icon: Package   },
    { id: 'locations',   label: 'Hub Locations', icon: MapPin    },
    { id: 'scanner',     label: 'Scanner',       icon: Scan      },
    { id: 'tracking',    label: 'Tracking',      icon: Search    },
  ];

  return (
    <nav style={{
      position: 'sticky',
      top: 0,
      zIndex: 100,
      background: '#fff',
      borderBottom: '1px solid var(--border-color)',
      boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
      padding: '0 24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      height: '60px',
      gap: '12px'
    }}>

      {/* Brand */}
      <div
        style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', flexShrink: 0 }}
        onClick={() => setActiveTab('dashboard')}
      >
        <div style={{
          background: isDriver ? 'linear-gradient(135deg, #1e3a8a, #3b82f6)' : 'linear-gradient(135deg, #3b82f6, #0284c7)',
          width: '34px', height: '34px',
          borderRadius: '9px',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: isDriver ? '0 3px 8px rgba(30, 58, 138, 0.35)' : '0 3px 8px rgba(59, 130, 246, 0.35)'
        }}>
          {isDriver ? (
            <Truck size={18} color="#fff" strokeWidth={2.5} />
          ) : (
            <Package size={18} color="#fff" strokeWidth={2.5} />
          )}
        </div>
        <div>
          <span style={{
            fontFamily: 'var(--font-display)', fontWeight: 800,
            fontSize: '1.1rem', color: isDriver ? '#1e3a8a' : '#3b82f6',
            letterSpacing: '-0.03em'
          }}>ARQON</span>
          <span style={{
            fontSize: '0.6rem', display: 'block',
            color: 'var(--text-muted)', marginTop: '-2px',
            fontWeight: 600, letterSpacing: '0.06em'
          }}>LOGISTICS PLATFORM</span>
        </div>
      </div>

      {/* Nav Links */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '2px', overflowX: 'auto' }}>
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              style={{
                display: 'flex', alignItems: 'center', gap: '6px',
                padding: '7px 14px',
                borderRadius: '8px', border: 'none',
                background: isActive ? (isDriver ? 'rgba(30, 58, 138, 0.12)' : 'var(--primary-glow)') : 'transparent',
                color: isActive ? (isDriver ? '#1e3a8a' : 'var(--primary)') : 'var(--text-secondary)',
                cursor: 'pointer', fontWeight: isActive ? 700 : 500,
                fontSize: '0.85rem', transition: 'var(--transition-fast)',
                whiteSpace: 'nowrap',
                borderBottom: isActive ? (isDriver ? '2px solid #1e3a8a' : '2px solid var(--primary)') : '2px solid transparent',
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = '#f8fafc'; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = 'transparent'; }}
            >
              <Icon size={15} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* User Area */}
      {user && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexShrink: 0 }}>
          {user.role === 'ADMIN'
            ? <span className="badge badge-admin"><Shield size={10} /> Admin</span>
            : user.role === 'DRIVER'
            ? <span className="badge" style={{ background: '#dbeafe', color: '#1e40af', border: '1px solid #bfdbfe' }}><Truck size={10} /> Driver</span>
            : <span className="badge badge-operator"><User size={10} /> Operator</span>
          }
          <span style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-primary)' }}>
            {user.username}
          </span>
          <button
            onClick={logout}
            className="btn-icon delete"
            title="Log Out"
          >
            <LogOut size={15} />
          </button>
        </div>
      )}
    </nav>
  );
}
