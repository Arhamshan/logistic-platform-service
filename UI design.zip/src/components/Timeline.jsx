import React from 'react';
import { Package, Truck, CheckCircle2, AlertCircle, Bookmark, Compass, RefreshCw } from 'lucide-react';

export default function Timeline({ events = [], consignmentId }) {
  if (events.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--text-secondary)' }}>
        <AlertCircle size={36} style={{ color: 'var(--text-muted)', marginBottom: '12px' }} />
        <p style={{ fontWeight: 500 }}>No tracking history found for consignment.</p>
        <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Scan items at hubs to generate events.</p>
      </div>
    );
  }

  // Helper to resolve event style and icon
  const getEventMeta = (type) => {
    const normType = type ? type.toUpperCase() : 'SCANNED';
    switch (normType) {
      case 'BOOKED':
      case 'PENDING':
        return {
          color: 'var(--warning)',
          glow: 'var(--warning-glow)',
          icon: Bookmark,
          label: 'Cargo Booked'
        };
      case 'SORTING':
      case 'RECEIVED':
        return {
          color: 'var(--primary)', // Electric Purple
          glow: 'var(--purple-glow)',
          icon: Package,
          label: 'In Hub / Sorting Terminal'
        };
      case 'DISPATCHED':
      case 'IN_TRANSIT':
        return {
          color: 'var(--accent-cyan)', // Cyan Spark
          glow: 'var(--accent-cyan-glow)',
          icon: Truck,
          label: 'Dispatched / In Transit'
        };
      case 'DELIVERED':
        return {
          color: 'var(--success)', // Emerald Green
          glow: 'var(--success-glow)',
          icon: CheckCircle2,
          label: 'Delivered successfully'
        };
      default:
        return {
          color: 'var(--text-secondary)',
          glow: 'rgba(255,255,255,0.05)',
          icon: Compass,
          label: normType
        };
    }
  };

  const formatDate = (isoStr) => {
    if (!isoStr) return '';
    const date = new Date(isoStr);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const isDelivered = events.some(e => e.eventType === 'DELIVERED');

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <div>
          <span style={{ fontSize: '0.8rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)' }}>
            Consignment Tracking ID
          </span>
          <h3 style={{ fontSize: '1.25rem', color: 'var(--primary)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
            {consignmentId}
          </h3>
        </div>
        <span className="badge badge-operator" style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
          <RefreshCw size={12} className="pulse-primary" /> Active Feed
        </span>
      </div>

      <div style={{ position: 'relative', paddingLeft: '24px', marginLeft: '12px' }}>
        {/* Vertical gradient trace line */}
        <div style={{
          position: 'absolute',
          left: '0',
          top: '8px',
          bottom: '8px',
          width: '2px',
          background: 'linear-gradient(to bottom, var(--primary), var(--accent-cyan), var(--border-color))',
          borderRadius: '1px'
        }} />

        {/* Existing events list */}
        {events.map((event, index) => {
          const meta = getEventMeta(event.eventType);
          const Icon = meta.icon;
          const isLatest = index === events.length - 1;

          return (
            <div key={event.id || index} className="animate-slideup" style={{
              position: 'relative',
              marginBottom: '24px',
              animationDelay: `${index * 0.08}s`
            }}>
              {/* Timeline bubble node */}
              <div style={{
                position: 'absolute',
                left: '-36px',
                top: '2px',
                width: '24px',
                height: '24px',
                borderRadius: '50%',
                backgroundColor: 'var(--bg-primary)',
                border: `2px solid ${meta.color}`,
                boxShadow: isLatest ? `0 0 12px ${meta.color}` : 'none',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                zIndex: 2,
                transition: 'var(--transition-fast)'
              }} className={isLatest ? 'pulse-primary' : ''}>
                <Icon size={12} style={{ color: meta.color }} />
              </div>

              {/* Event content card */}
              <div className="glass-panel" style={{
                padding: '14px 18px',
                background: isLatest ? 'rgba(139, 92, 246, 0.05)' : 'var(--bg-surface)',
                borderColor: isLatest ? 'var(--primary)' : 'var(--border-color)',
                boxShadow: isLatest ? '0 0 20px rgba(139, 92, 246, 0.15)' : 'none',
                borderRadius: '12px'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '8px' }}>
                  <div>
                    <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                      {meta.label}
                      <span style={{ fontSize: '0.75rem', fontWeight: 500, color: 'var(--text-muted)' }}>
                        at hub:
                      </span>
                      <span className="code-tag" style={{ color: 'var(--primary)' }}>
                        {event.locationCode}
                      </span>
                    </h4>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
                      {event.remarks}
                    </p>
                  </div>
                  
                  <div style={{ textAlign: 'right' }}>
                    <span style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-muted)', display: 'block' }}>
                      {formatDate(event.timestamp)}
                    </span>
                    {event.operatorId && (
                      <span className="code-tag" style={{ fontSize: '0.65rem', color: 'var(--text-muted)', background: 'rgba(255,255,255,0.03)', padding: '2px 6px', borderRadius: '4px' }}>
                        OP: {event.operatorId}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {/* Dynamic grayed out placeholder destination hub */}
        {!isDelivered && (
          <div className="animate-slideup" style={{
            position: 'relative',
            opacity: 0.45,
            transition: 'opacity var(--transition-normal)'
          }}>
            <div style={{
              position: 'absolute',
              left: '-36px',
              top: '2px',
              width: '24px',
              height: '24px',
              borderRadius: '50%',
              backgroundColor: 'var(--bg-primary)',
              border: '2px solid var(--text-muted)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              zIndex: 2
            }}>
              <CheckCircle2 size={12} style={{ color: 'var(--text-muted)' }} />
            </div>

            <div className="glass-panel" style={{
              padding: '14px 18px',
              background: 'rgba(255,255,255,0.01)',
              borderColor: 'var(--border-color)',
              borderRadius: '12px'
            }}>
              <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-secondary)' }}>
                Delivery Destination (Pending)
              </h4>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Remaining journey nodes will display once parcel arrives at final sorting gateway.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
