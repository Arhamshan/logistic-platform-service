import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import Login from './views/Login';
import Dashboard from './views/Dashboard';
import DriverDashboard from './views/DriverDashboard';
import Consignments from './views/Consignments';
import Locations from './views/Locations';
import Scanner from './views/Scanner';
import Tracking from './views/Tracking';
import './App.css';

function MainAppContent() {
  const { user, token, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  // Keyboard shortcuts
  useEffect(() => {
    if (!token) return;
    const handleKeyDown = (e) => {
      const activeEl = document.activeElement;
      const isTyping = activeEl && (
        activeEl.tagName === 'INPUT' ||
        activeEl.tagName === 'TEXTAREA' ||
        activeEl.isContentEditable
      );
      if (e.ctrlKey && e.key.toLowerCase() === 's') {
        e.preventDefault();
        setActiveTab('scanner');
        setTimeout(() => { document.getElementById?.('scanner-input')?.focus(); }, 80);
      }
      if (e.ctrlKey && e.key.toLowerCase() === 'b') {
        e.preventDefault();
        setActiveTab('consignments');
      }
      if (e.key === '/' && !isTyping) {
        e.preventDefault();
        setActiveTab('tracking');
        setTimeout(() => { document.querySelector?.('.tracking-input')?.focus(); }, 80);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [token]);

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-primary)' }}>
        <div style={{ width: 36, height: 36, border: '3px solid var(--primary-glow)', borderTopColor: 'var(--primary)', borderRadius: '50%', animation: 'spin 1s linear infinite', marginBottom: 14 }} />
        <span style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', fontFamily: 'var(--font-display)', fontWeight: 600 }}>
          Loading ARQON Platform…
        </span>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (!token) return <Login />;

  const isDriver = user?.role === 'DRIVER';

  const renderView = () => {
    // For drivers, use driver dashboard for POD and tracking
    if (isDriver && (activeTab === 'dashboard' || activeTab === 'driver-portal')) {
      return <DriverDashboard setActiveTab={setActiveTab} />;
    }

    switch (activeTab) {
      case 'dashboard':    return <Dashboard setActiveTab={setActiveTab} />;
      case 'driver-portal': return <DriverDashboard setActiveTab={setActiveTab} />;
      case 'consignments': return <Consignments />;
      case 'locations':    return <Locations />;
      case 'scanner':      return <Scanner />;
      case 'tracking':     return <Tracking />;
      default:             return isDriver ? <DriverDashboard setActiveTab={setActiveTab} /> : <Dashboard setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)' }}>
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main style={{ paddingTop: 28 }}>
        {renderView()}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
    </AuthProvider>
  );
}
