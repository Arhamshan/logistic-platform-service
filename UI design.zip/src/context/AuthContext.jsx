import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if token and user data exist in localStorage
    const savedToken = localStorage.getItem('arqon_token');
    const savedUsername = localStorage.getItem('arqon_username');
    const savedRole = localStorage.getItem('arqon_role');

    if (savedToken && savedUsername && savedRole) {
      setToken(savedToken);
      setUser({ username: savedUsername, role: savedRole });
    }
    setLoading(false);
  }, []);

  const login = (tokenValue, username, role) => {
    localStorage.setItem('arqon_token', tokenValue);
    localStorage.setItem('arqon_username', username);
    localStorage.setItem('arqon_role', role);
    setToken(tokenValue);
    setUser({ username, role });
  };

  const logout = () => {
    localStorage.removeItem('arqon_token');
    localStorage.removeItem('arqon_username');
    localStorage.removeItem('arqon_role');
    setToken(null);
    setUser(null);
  };

  const registerDemoUser = (username, role) => {
    // Helper to log in a demo user immediately without backend during mock testing
    const demoToken = `demo-jwt-token-${Math.random().toString(36).substring(2)}`;
    login(demoToken, username, role);
    return { token: demoToken, username, role };
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, logout, registerDemoUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
